package com.example.cobt2.finalyearproject;

import java.util.Random;

public class Coach {
    String name;
    String positionCoached;

    int uniqueID = new Random().nextInt(999999);

    public Coach() {}

    public Coach(String name, String positionCoached, int uniqueID) {
        this.name = name;
        this.positionCoached = positionCoached;
        this.uniqueID = uniqueID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPositionCoached() {
        return positionCoached;
    }

    public void setPositionCoached(String positionCoached) {
        this.positionCoached = positionCoached;
    }

    public int getUniqueID() {
        return uniqueID;
    }

    public void setUniqueID(int uniqueID) {
        this.uniqueID = uniqueID;
    }
}




