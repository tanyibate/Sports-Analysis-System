package com.example.cobt2.finalyearproject;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.gson.Gson;
import com.google.gson.JsonElement;

import java.util.HashMap;


public class fieldgoal extends Fragment {

    Button fgmiss;
    Button setkicker;
    Button fgblocked;
    Button fgconverted;
    Button fakefieldgoal;
    Button rush;
    Button fumble;
    Button turnover;
    Button offence;
    Button defence;
    Button ballrecovered;
    Button automaticfirstdown;
    Button turnovertd;
    Button restart;
    Button setpenalty;
    EditText kicker;
    EditText fgdistance;
    EditText rusher;
    EditText yardsgained;


    DocumentReference doc;








    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    // The onCreateView method is called when Fragment should create its View object hierarchy,
    // either dynamically or via XML layout inflation.
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup parent, Bundle savedInstanceState) {
        // Defines the xml file for the fragment
        return inflater.inflate(R.layout.fragment_fieldgoal, parent, false);
    }

    // This event is triggered soon after onCreateView().
    // Any view setup should occur here.  E.g., view lookups and attaching view listeners.
    @Override
    public void onViewCreated(final View view, Bundle savedInstanceState) {
        fgconverted = view.findViewById(R.id.fgconverted);
        fgconverted.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                pointgood();
                fgmade();
                Toast.makeText(view.getContext(),"Field Goal Converted",Toast.LENGTH_SHORT).show();

                // Code here executes on main thread after user presses button
            }
        });
        fgmiss = view.findViewById(R.id.fgmiss);
        fgmiss.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                fgmiss();
                Toast.makeText(view.getContext(),"Field Goal Missed",Toast.LENGTH_SHORT).show();

                // Code here executes on main thread after user presses button
            }
        });





        kicker = view.findViewById(R.id.kicker);
        fgdistance = view.findViewById(R.id.fieldgoaldistance);








        // Setup any handles to view objects here
        // EditText etFoo = (EditText) view.findViewById(R.id.etFoo);
    }
    public void fgmade() {
        doc = RecordGame.database.collection("players").document(kicker.getText().toString());
        doc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Player kck = document.toObject(Player.class);

                        kck.setFgConverted(kck.getFgConverted()+1);
                        kck.setFgAttempted(kck.getFgAttempted()+1);
                        if(kck.getFgLong()<Integer.valueOf(fgdistance.getText().toString()))
                        {

                            kck.setFgLong(Integer.valueOf(fgdistance.getText().toString()));


                        }
                        DocumentReference docRef = RecordGame.database.collection("weeks").document(kicker.getText().toString());
                        docRef.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                            @Override
                            public void onSuccess(DocumentSnapshot documentSnapshot) {
                                double distance = documentSnapshot.getDouble(RecordGame.weekselected + ".fgLong");
                                if(distance<Double.valueOf(fgdistance.getText().toString())){
                                    RecordGame.database.collection("weeks").document(kicker.getText().toString()).update(RecordGame.weekselected + ".fgLong",Integer.valueOf(fgdistance.getText().toString()) );

                                }
                            }
                        });


                        RecordGame.database.collection("players").document(kicker.getText().toString()).set(kck);
                        RecordGame.database.collection("weeks").document(kicker.getText().toString()).update(RecordGame.weekselected + ".fgConverted", FieldValue.increment(1));
                        RecordGame.database.collection("weeks").document(kicker.getText().toString()).update(RecordGame.weekselected + ".fgAttempted", FieldValue.increment(1));





                    } else {
                        //
                    }
                } else {
                    //
                }
            }
        });

    }

    public void pointgood(){
        RecordGame.database.collection("weeks").document("games").update(RecordGame.weekselected + ".teamscore", FieldValue.increment(3))
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        DocumentReference doc = RecordGame.database.collection("weeks").document("games");
                        doc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                if (task.isSuccessful()) {
                                    DocumentSnapshot document = task.getResult();
                                    if (document.exists()) {

                                        HashMap<String, Object> myMap = (HashMap<String, Object>) document.get(RecordGame.weekselected);
                                        Gson gson = new Gson();
                                        JsonElement jsonElement = gson.toJsonTree(myMap);
                                        opponent gameselected = gson.fromJson(jsonElement, opponent.class);
                                        RecordGame.score.setText("Score: LOU "+ gameselected.getTeamscore() + " : " + gameselected.getOpponentscore()+" "+ gameselected.getOpponentabreviation());


                                    } else {
                                        //
                                    }
                                } else {
                                    //
                                }
                            }
                        });
                    }
                });


    }

    public void fgmiss() {
        doc = RecordGame.database.collection("players").document(kicker.getText().toString());
        doc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Player kck = document.toObject(Player.class);
                        kck.setFgAttempted(kck.getFgAttempted()+1);





                    } else {
                        //
                    }
                } else {
                    //
                }
            }
        });

    }












}



