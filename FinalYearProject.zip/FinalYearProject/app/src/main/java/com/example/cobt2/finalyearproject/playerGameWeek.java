package com.example.cobt2.finalyearproject;

public class playerGameWeek extends Player {


    String opponent;
    int rating;

    public playerGameWeek(){}

    public playerGameWeek(String opponent, int rating) {
        this.opponent = opponent;
        this.rating = rating;
    }



    public String getOpponent() {
        return opponent;
    }

    public void setOpponent(String opponent) {
        this.opponent = opponent;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }



}
