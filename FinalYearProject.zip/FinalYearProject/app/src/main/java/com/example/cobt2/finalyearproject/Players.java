package com.example.cobt2.finalyearproject;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;

import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;
import com.jjoe64.graphview.series.Series;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;

public class Players extends AppCompatActivity {


    static FirebaseFirestore db;
    static String name;
    static String position;
    static int number;
    static int weight;
    static int feet;
    static int inches;
    static String tempnumber;
    static float forty;
    static int year;
    static int month;
    static int day;
    static Calendar dob = Calendar.getInstance();
    ListView listView;
    String playerselected;
    String playerpostion;
    Toast toastMessage;
    TextView player;
    String text ="";





// ...


    public static ArrayList<HashMap<String, String>> list;
    public static final String FIRST_COLUMN="First";
    public static final String SECOND_COLUMN="Second";
    public static final String THIRD_COLUMN="Third";
    public static final String FOURTH_COLUMN="Fourth";
    static ListViewAdapter3 adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_players);
        db = FirebaseFirestore.getInstance();
        player = findViewById(R.id.playerselected);

       // spinner = (Spinner) findViewById(R.id.position);
// Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> badapter = ArrayAdapter.createFromResource(this,
                R.array.postions, android.R.layout.simple_spinner_item);
// Specify the layout to use when the list of choices appears
        badapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        //spinner.setAdapter(badapter);
       // playernumber = (EditText) findViewById(R.id.playernumber);
        //playername = (EditText) findViewById(R.id.playername);
        //db = FirebaseFirestore.getInstance();

        listView=(ListView)findViewById(R.id.listView1);
        populateList();
        adapter =new ListViewAdapter3(this, list);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                TextView textView = (TextView) view.findViewById(R.id.TextFirst);
                TextView textView2 = (TextView) view.findViewById(R.id.TextThird);


                text = textView.getText().toString();
                String text2 = textView2.getText().toString();

                player.setText("Player Selected: "+ text);
                if (toastMessage!= null) {
                    toastMessage.cancel();
                }

                toastMessage.makeText(getApplicationContext(), "Selected " + text, Toast.LENGTH_SHORT).show();
                playerselected = text2;

                final FirebaseFirestore database = FirebaseFirestore.getInstance();

                DocumentReference doc = database.collection("players").document(playerselected);
                    doc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                            if (task.isSuccessful()) {
                                DocumentSnapshot document = task.getResult();
                                if (document.exists()) {
                                    Player passerInPlay = document.toObject(Player.class);
                                    playerpostion = passerInPlay.getPosition();





                                } else {
                                    //
                                }
                            } else {
                                //
                            }
                        }
                    });


//where list_content is the id of TextView in listview_item.xml

            }});

        // Begin the transaction
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        // Replace the contents of the container with the new fragment
        ft.replace(R.id.registercontainer, new newplayer());
        // or ft.add(R.id.your_placeholder, new FooFragment());
        // Complete the changes added above
        ft.commit();

    }


    public static void populateList() {
        // TODO Auto-generated method stub

        list=new ArrayList<HashMap<String,String>>();



        /*for(int i=0;i<=100;i++) {


            String number = Integer.toString(i);

            DocumentReference docRef = db.collection("players").document(number);
            docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                    if (task.isSuccessful()) {
                        DocumentSnapshot document = task.getResult();
                        if (document.exists()) {
                            Player upload = document.toObject(Player.class);
                            HashMap<String, String> hashmap4 = new HashMap<String, String>();
                            hashmap4.put(FIRST_COLUMN, upload.getName());
                            hashmap4.put(SECOND_COLUMN, upload.getPosition());
                            hashmap4.put(THIRD_COLUMN, Integer.toString(upload.getNumber()));
                            hashmap4.put(FOURTH_COLUMN, "App");
                            list.add(hashmap4);

                        } else {
                            //
                        }
                    } else {
                        //
                    }
                }
            });

        }*/
        db.collection("players")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                Player upload = document.toObject(Player.class);
                                HashMap<String, String> hashmap4 = new HashMap<String, String>();
                                hashmap4.put(FIRST_COLUMN, upload.getName());
                                hashmap4.put(SECOND_COLUMN, upload.getPosition());
                                hashmap4.put(THIRD_COLUMN, Integer.toString(upload.getNumber()));
                                hashmap4.put(FOURTH_COLUMN,  Integer.toString(upload.getUniqueID()));
                                list.add(hashmap4);
                            }
                        } else {

                        }
                    }
                });



    }



    public static void addPlayers() {


        Player player = new Player();
        player.setName(name);
        player.setPosition(position);
        player.setNumber(number);
        player.setForty(forty);
        player.setWeight(weight);
        player.setInches(inches);
        player.setFeet(feet);
        player.setYear(year);
        player.setMonth(month);
        player.setDay(day);





        HashMap<String,String> hashmap=new HashMap<String, String>();
        hashmap.put(FIRST_COLUMN,name);
        hashmap.put(SECOND_COLUMN,position);
        hashmap.put(THIRD_COLUMN,tempnumber);

        list.add(hashmap);
        adapter.notifyDataSetChanged();
        //User user = new User(name,number,pos);

        db.collection("players").document(tempnumber).set(player);






    }

    public void select(View view){



        Intent selectIntent = new Intent(Players.this ,playerStats.class);
        selectIntent.putExtra("number",playerselected);
        selectIntent.putExtra("postion",playerpostion);

        startActivity(selectIntent);


    }
}
