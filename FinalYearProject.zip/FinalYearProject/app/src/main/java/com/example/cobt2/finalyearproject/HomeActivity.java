package com.example.cobt2.finalyearproject;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

public class HomeActivity extends AppCompatActivity {

    EditText username ;
    EditText password ;
    FirebaseFirestore db;
    String number;
    String position;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        username = (EditText) findViewById(R.id.lastname);
        password = (EditText) findViewById(R.id.number);
        db = FirebaseFirestore.getInstance();

        //List.populateList();


    }



    public void login(View view) {
        if (username.getText().toString().equals("admin") && password.getText().toString().equals("admin")) {

            //correct password
            Intent optionIntent = new Intent(HomeActivity.this ,OptionScreen.class);
            startActivity(optionIntent);
            finish();
        } else {
            //wrong password
        }
    }

    public void register(View view) {



            Intent optionIntent = new Intent(HomeActivity.this ,createAccount.class);
            startActivity(optionIntent);
            finish();


        }


        public void signin(View view){

            DocumentReference docRef = db.collection("users").document(username.getText().toString());
            docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                    if (task.isSuccessful()) {
                        DocumentSnapshot document = task.getResult();
                        if (document.exists()) {
                            final Intent playerStats = new Intent(HomeActivity.this ,playerStats.class);
                            final String uniqueID = (String) document.get("uniqueID");
                            if(document.get("password").equals(password.getText().toString())){
                                if(document.get("userType").equals("Player")){
                                    db.collection("players")
                                            .get()
                                            .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                                @Override
                                                public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                                    if (task.isSuccessful()) {
                                                        for (QueryDocumentSnapshot document : task.getResult()) {
                                                            if(((String) document.get("uniqueID")).equals(uniqueID)){
                                                                number = Double.toString(document.getDouble("number"));
                                                                System.out.println(number);
                                                                Log.d("hello",number);
                                                                position = (String) document.get("position");
                                                                playerStats.putExtra("number",number);
                                                                playerStats.putExtra("postion",position);
                                                            }
                                                        }
                                                    } else {

                                                    }
                                                }
                                            });
                                    startActivity(playerStats);
                                }
                                else{
                                    Intent optionIntent = new Intent(HomeActivity.this ,OptionScreen.class);


                                    startActivity(optionIntent);
                                    finish();

                                }

                            }

                        } else {

                        }
                    } else {

                    }
                }
            });
        }
    }


