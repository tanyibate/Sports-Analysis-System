package com.example.cobt2.finalyearproject;

import android.support.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.HashMap;

public class List {
    public static ArrayList<HashMap<String, String>> list;

    public static final String FIRST_COLUMN="First";
    public static final String SECOND_COLUMN="Second";
    public static final String THIRD_COLUMN="Third";
    public static final String FOURTH_COLUMN="Fourth";

    public static FirebaseFirestore db;

    public static void populateList() {
        // TODO Auto-generated method stub

        list=new ArrayList<HashMap<String,String>>();



        for(int i=0;i<=100;i++) {


            String number = Integer.toString(i);

            DocumentReference docRef = db.collection("players").document(number);
            docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                    if (task.isSuccessful()) {
                        DocumentSnapshot document = task.getResult();
                        if (document.exists()) {
                            Player upload = document.toObject(Player.class);
                            HashMap<String, String> hashmap4 = new HashMap<String, String>();
                            hashmap4.put(FIRST_COLUMN, upload.getName());
                            hashmap4.put(SECOND_COLUMN, upload.getPosition());
                            hashmap4.put(THIRD_COLUMN, Integer.toString(upload.getNumber()));
                            hashmap4.put(FOURTH_COLUMN, "App");
                            list.add(hashmap4);

                        } else {
                            //
                        }
                    } else {
                        //
                    }
                }
            });

        }



    }
}
