package com.example.cobt2.finalyearproject;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;

public class Users extends AppCompatActivity {

    ListView listView;
    String playerselected;
    String playerpostion;
    Toast toastMessage;
    TextView player;
    String text ="";
    static FirebaseFirestore db;
    EditText name,username,password;





// ...


    public static ArrayList<HashMap<String, String>> list;
    public static final String FIRST_COLUMN="First";
    public static final String SECOND_COLUMN="Second";
    public static final String THIRD_COLUMN="Third";
    public static final String FOURTH_COLUMN="Fourth";
    static ListViewAdapter4 adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_modifyusers);
        db = FirebaseFirestore.getInstance();
        username = findViewById(R.id.username);
        name = findViewById(R.id.name);
        password = findViewById(R.id.password);


        listView = findViewById(R.id.listView1);
        populateList();
        adapter =new ListViewAdapter4(this, list);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                TextView textView = (TextView) view.findViewById(R.id.TextFirst);
                TextView textView4 = (TextView) view.findViewById(R.id.textFourth);
                TextView textView2 = (TextView) view.findViewById(R.id.TextSecond);
                TextView textView3 = (TextView) view.findViewById(R.id.TextThird);

                username.setText(textView2.getText().toString());
                password.setText(textView3.getText().toString());
                name.setText(textView.getText().toString());





//where list_content is the id of TextView in listview_item.xml

            }});
    }

    public static void populateList() {
        // TODO Auto-generated method stub

        list=new ArrayList<HashMap<String,String>>();




        db.collection("users")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                User upload = document.toObject(User.class);
                                HashMap<String, String> hashmap4 = new HashMap<String, String>();
                                hashmap4.put(FIRST_COLUMN, upload.getFirstname()+" "+upload.getLastname());
                                hashmap4.put(SECOND_COLUMN, upload.getUsername());
                                hashmap4.put(THIRD_COLUMN, upload.getPassword());
                                hashmap4.put(FOURTH_COLUMN,  upload.getUserType());
                                list.add(hashmap4);
                            }
                        } else {

                        }
                    }
                });



    }
}
