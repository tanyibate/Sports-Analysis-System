package com.example.cobt2.finalyearproject;

public class opponent {
    int defensiveturnovers, offensiveturnovers,yardsgained,yardsgivenup,teamscore,opponentscore;
    String opponent,opponentabreviation;
    boolean played = false;

    public opponent(){}

    public opponent(int defensiveturnovers, int offensiveturnovers, int yardsgained, int yardsgivenup, int teamscore, int opponentscore, String opponent, String opponentabreviation, boolean played) {
        this.defensiveturnovers = defensiveturnovers;
        this.offensiveturnovers = offensiveturnovers;
        this.yardsgained = yardsgained;
        this.yardsgivenup = yardsgivenup;
        this.teamscore = teamscore;
        this.opponentscore = opponentscore;
        this.opponent = opponent;
        this.opponentabreviation = opponentabreviation;
        this.played = played;
    }

    public int getDefensiveturnovers() {
        return defensiveturnovers;
    }

    public void setDefensiveturnovers(int defensiveturnovers) {
        this.defensiveturnovers = defensiveturnovers;
    }

    public int getOffensiveturnovers() {
        return offensiveturnovers;
    }

    public void setOffensiveturnovers(int offensiveturnovers) {
        this.offensiveturnovers = offensiveturnovers;
    }

    public int getYardsgained() {
        return yardsgained;
    }

    public void setYardsgained(int yardsgained) {
        this.yardsgained = yardsgained;
    }

    public int getYardsgivenup() {
        return yardsgivenup;
    }

    public void setYardsgivenup(int yardsgivenup) {
        this.yardsgivenup = yardsgivenup;
    }

    public int getTeamscore() {
        return teamscore;
    }

    public void setTeamscore(int teamscore) {
        this.teamscore = teamscore;
    }

    public int getOpponentscore() {
        return opponentscore;
    }

    public void setOpponentscore(int opponentscore) {
        this.opponentscore = opponentscore;
    }

    public String getOpponent() {
        return opponent;
    }

    public void setOpponent(String opponent) {
        this.opponent = opponent;
    }

    public String getOpponentabreviation() {
        return opponentabreviation;
    }

    public void setOpponentabreviation(String opponentabreviation) {
        this.opponentabreviation = opponentabreviation;
    }

    public boolean isPlayed() {
        return played;
    }

    public void setPlayed(boolean played) {
        this.played = played;
    }
}
