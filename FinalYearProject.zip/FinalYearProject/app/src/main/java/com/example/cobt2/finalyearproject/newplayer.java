package com.example.cobt2.finalyearproject;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;


public class newplayer extends Fragment {

    Button next;
    EditText playername;
    Spinner spinner;
    EditText playernumber;


    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    // The onCreateView method is called when Fragment should create its View object hierarchy,
    // either dynamically or via XML layout inflation.
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup parent, Bundle savedInstanceState) {
        // Defines the xml file for the fragment
        return inflater.inflate(R.layout.fragment_newplayer, parent, false);
    }

    // This event is triggered soon after onCreateView().
    // Any view setup should occur here.  E.g., view lookups and attaching view listeners.
    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {

        spinner = view.findViewById(R.id.position);
// Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> badapter = ArrayAdapter.createFromResource(getActivity().getApplicationContext(), R.array.postions, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        badapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        spinner.setAdapter(badapter);
        next = view.findViewById(R.id.next);
        playername = view.findViewById(R.id.playername);
        playernumber = view.findViewById(R.id.playernumber);
        next.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Code here executes on main thread after user presses button
                Players.position = spinner.getSelectedItem().toString();
                Players.name = playername.getText().toString();

                String tempnumber = playernumber.getText().toString();
                Players.tempnumber =tempnumber;
                Players.number = Integer.parseInt(tempnumber);
                // Begin the transaction
                // Begin the transaction
                // Create new fragment and transaction
                Fragment newFragment = new newplayer2();
                FragmentTransaction transaction = getFragmentManager().beginTransaction();

// Replace whatever is in the fragment_container view with this fragment,
// and add the transaction to the back stack if needed
                transaction.replace(R.id.registercontainer, newFragment);
                transaction.addToBackStack(null);

// Commit the transaction
                transaction.commit();
            }
        });






        // Setup any handles to view objects here
        // EditText etFoo = (EditText) view.findViewById(R.id.etFoo);
    }

    public void addPlayers(View view) {
        String pos = spinner.getSelectedItem().toString();
        String name = playername.getText().toString();

        String tempnumber = playernumber.getText().toString();
        int number = Integer.parseInt(tempnumber);

        Player player = new Player();
        player.setName(name);
        player.setPosition(pos);
        player.setNumber(number);




        //HashMap<String,String> hashmap=new HashMap<String, String>();
        //hashmap.put(FIRST_COLUMN,name);
        //hashmap.put(SECOND_COLUMN,pos);
        //hashmap.put(THIRD_COLUMN,tempnumber);

        //list.add(hashmap);
        //dapter.notifyDataSetChanged();
        //User user = new User(name,number,pos);
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("players").document(tempnumber).set(player);




    }

}
