package com.example.cobt2.finalyearproject;


import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;

/**
 * A simple {@link Fragment} subclass.
 */
public class FirstFragment extends Fragment {


    // Store instance variables
    private String title;
    private int page;
    private String number;
    TextView yards;
    TextView interceptions;
    TextView tds;
    //TextView rtg;

    // newInstance constructor for creating fragment with arguments
    public static FirstFragment newInstance(int page, String title, String playerselected) {
        FirstFragment fragmentFirst = new FirstFragment();
        Bundle args = new Bundle();
        args.putInt("someInt", page);
        args.putString("someTitle", title);
        args.putString("number",playerselected);
        fragmentFirst.setArguments(args);
        return fragmentFirst;

    }

    // Store instance variables based on arguments passed
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        page = getArguments().getInt("someInt", 0);
        title = getArguments().getString("someTitle");
        number = getArguments().getString("number");
    }

    // Inflate the view for the fragment based on layout XML
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_first, container, false);
        TextView tvLabel = (TextView) view.findViewById(R.id.tvLabel);
        tvLabel.setText(page + " -- " + title);
        yards = (TextView) view.findViewById(R.id.yds);
        interceptions = (TextView) view.findViewById(R.id.interceptions);
        tds = (TextView) view.findViewById(R.id.td);
        //rtg = (TextView) view.findViewById(R.id.rtg);
        seText();





        return view;
    }

    public void seText(){

        DocumentReference docRef = playerStats.database.collection("players").document(number);
        docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Player upload = document.toObject(Player.class);
                        tds.setText(String.valueOf(upload.getPassingTD()));
                        interceptions.setText(String.valueOf(upload.getInterceptions()));
                        yards.setText(String.valueOf(upload.getPassingYards()));
                        //Double rating = algorithms.passerRating(upload.getPassesCompleted(),upload.getPassesAttempted(),upload.getPassingTD(),upload.getInterceptions(),upload.getPassingYards());
                        //rtg.setText(String.valueOf(rating));


                    } else {
                        //
                    }
                } else {
                    //
                }
            }
        });
    }

}
