package com.example.cobt2.finalyearproject;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TableRow;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FieldValue.*;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;
import com.google.gson.Gson;
import com.google.gson.JsonElement;

import java.util.HashMap;
import java.util.Map;

public class Main2Activity extends AppCompatActivity {

    playerGameWeek player;
    double current;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
    }

    public void addPlayers(View view) {




        final FirebaseFirestore db = FirebaseFirestore.getInstance();




        //final HashMap<String,playerGameWeek> map = new HashMap<>();












                            DocumentReference docRef = db.collection("weeks").document("12");


                docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                @Override
                                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                    if (task.isSuccessful()) {
                                        DocumentSnapshot document = task.getResult();
                                        if (document.exists()) {

                                            current= document.getDouble("1.passesCompleted");
                                            db.collection("weeks").document("12").update("1.passesCompleted", FieldValue.increment(1));








                                        } else {
                                            //
                                        }
                                    } else {
                                        //
                                    }
                                }
                            });

























        /*doc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        HashMap<String, Object> myMap = (HashMap<String, Object>) document.get("1");
                        Gson gson = new Gson();
                        JsonElement jsonElement = gson.toJsonTree(myMap);
                        playerGameWeek player = gson.fromJson(jsonElement, playerGameWeek.class);


                        Log.d("hello",myMap.toString());
                        Log.d("hello1234",player.getName());











                        //Double rating = algorithms.passerRating(upload.getPassesCompleted(),upload.getPassesAttempted(),upload.getPassingTD(),upload.getInterceptions(),upload.getPassingYards());
                        //rtg.setText(String.valueOf(rating));


                    } else {

                        //
                    }
                } else {
                    //
                }
            }
        });*/















    }

        /*for (int i = 1; i <= 6; i++) {


            //FirebaseFirestore dbe = FirebaseFirestore.getInstance();
            DocumentReference docRef = db.collection("week" + i).document("12");
            final int finalI = i;
            docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                    if (task.isSuccessful()) {
                        DocumentSnapshot document = task.getResult();
                        if (document.exists()) {
                            player = document.toObject(playerGameWeek.class);
                            map.put(Integer.toString(finalI),player);


                            db.collection("weeks").document("12").set(map, SetOptions.merge());











                            //Double rating = algorithms.passerRating(upload.getPassesCompleted(),upload.getPassesAttempted(),upload.getPassingTD(),upload.getInterceptions(),upload.getPassingYards());
                            //rtg.setText(String.valueOf(rating));


                        } else {

                            //
                        }
                    } else {
                        //
                    }
                }
            });















        }*/













    }

