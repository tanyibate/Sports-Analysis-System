package com.example.cobt2.finalyearproject;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.gson.Gson;
import com.google.gson.JsonElement;

import java.util.HashMap;


public class Defense extends Fragment {

    Button recordtackle;
    Button recordsack;
    Button runoutofbounds;
    Button incompleteplass;
    Button interception;
    Button pick6;
    Button oyardsconfirm;
    Button offence;
    Button pr;
    EditText tackledby;
    EditText assistedby;
    EditText sackedby;
    EditText sackassistedby;
    EditText oyards;
    EditText startingposition;
    DocumentReference doc;
    Button penalty;
    Button restart;
    EditText pd;
    EditText fbrecoverer;
    Button tdconceded;




    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }
    // The onCreateView method is called when Fragment should create its View object hierarchy,
    // either dynamically or via XML layout inflation.
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup parent, Bundle savedInstanceState) {
        // Defines the xml file for the fragment
        return inflater.inflate(R.layout.fragment_defense, parent, false);
    }

    // This event is triggered soon after onCreateView().
    // Any view setup should occur here.  E.g., view lookups and attaching view listeners.
    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {

        tackledby = (EditText) view.findViewById(R.id.tackledby);
        recordtackle = (Button) view.findViewById(R.id.recordtackle);
        pd= view.findViewById(R.id.rusher);
        oyards = view.findViewById(R.id.yardsgivenup);

        fbrecoverer = view.findViewById(R.id.fbrecoverer);
        recordsack = view.findViewById(R.id.recordsack);
        tdconceded = view.findViewById(R.id.tdconceded);
        tdconceded.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                tdconceded();

                // Code here executes on main thread after user presses button
            }
        });

        assistedby = view.findViewById(R.id.assistedby);
        sackedby = view.findViewById(R.id.sacker);
        recordsack.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                sack();
                assistedsack();
                // Code here executes on main thread after user presses button
            }
        });
        sackassistedby = view.findViewById(R.id.sackassist);
        restart = (Button) view.findViewById(R.id.restart);
        restart.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                restart();

                // Code here executes on main thread after user presses button
            }
        });
        penalty = view.findViewById(R.id.penalty);
        recordtackle.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                tackle();
                assistedtackle();
                // Code here executes on main thread after user presses button
            }
        });
        incompleteplass = view.findViewById(R.id.incompletepass);
        incompleteplass.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                passdefended();
                // Code here executes on main thread after user presses button
            }
        });
        interception = view.findViewById(R.id.interception);
        interception.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                passdefended();
                // Code here executes on main thread after user presses button
            }
        });
        pick6 = view.findViewById(R.id.pick6);
        pick6.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                pick6();
                td();
                // Code here executes on main thread after user presses button
            }
        });





        // Setup any handles to view objects here
        // EditText etFoo = (EditText) view.findViewById(R.id.etFoo);
    }

    public void tackle() {
        doc = RecordGame.database.collection("players").document(tackledby.getText().toString());
        doc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Player tackle = document.toObject(Player.class);
                        tackle.setTackles(tackle.getTackles()+1);

                        RecordGame.database.collection("players").document(tackledby.getText().toString()).set(tackle);
                        RecordGame.database.collection("weeks").document(tackledby.getText().toString()).update(RecordGame.weekselected + ".tackles", FieldValue.increment(1 ));




                    } else {
                        //
                    }
                } else {
                    //
                }
            }
        });

    }

    public void assistedtackle() {
        doc = RecordGame.database.collection("players").document(assistedby.getText().toString());
        doc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Player asssistedtackle = document.toObject(Player.class);
                        asssistedtackle.setAssistedTackles(asssistedtackle.getAssistedTackles()+1);

                        RecordGame.database.collection("players").document(assistedby.getText().toString()).set(asssistedtackle);
                        RecordGame.database.collection("weeks").document(assistedby.getText().toString()).update(RecordGame.weekselected + ".assistedtackles", FieldValue.increment(1 ));




                    } else {
                        //
                    }
                } else {
                    //
                }
            }
        });

    }
    public void sack() {
        doc = RecordGame.database.collection("players").document(sackedby.getText().toString());
        doc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Player tackle = document.toObject(Player.class);
                        tackle.setTackles(tackle.getTackles()+1);

                        RecordGame.database.collection("players").document(sackedby.getText().toString()).set(tackle);
                        RecordGame.database.collection("weeks").document(sackedby.getText().toString()).update(RecordGame.weekselected + ".sacks", FieldValue.increment(1 ));




                    } else {
                        //
                    }
                } else {
                    //
                }
            }
        });

    }

    public void assistedsack() {
        doc = RecordGame.database.collection("players").document(sackassistedby.getText().toString());
        doc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Player asssistedtackle = document.toObject(Player.class);
                        asssistedtackle.setAssistedTackles(asssistedtackle.getAssistedTackles()+1);

                        RecordGame.database.collection("players").document(sackassistedby.getText().toString()).set(asssistedtackle);
                        RecordGame.database.collection("weeks").document(sackassistedby.getText().toString()).update(RecordGame.weekselected + ".sacks", FieldValue.increment(1));




                    } else {
                        //
                    }
                } else {
                    //
                }
            }
        });

    }

    public void passdefended() {
        doc = RecordGame.database.collection("players").document(pd.getText().toString());
        doc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Player DB = document.toObject(Player.class);
                        DB.setPassesDefended(DB.getPassesDefended()+1);

                        RecordGame.database.collection("players").document(pd.getText().toString()).set(DB);
                        RecordGame.database.collection("weeks").document(pd.getText().toString()).update(RecordGame.weekselected + ".passesDefended", FieldValue.increment(1));




                    } else {
                        //
                    }
                } else {
                    //
                }
            }
        });

    }

    public void interception() {
        doc = RecordGame.database.collection("players").document(pd.getText().toString());
        doc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Player DB = document.toObject(Player.class);
                        DB.setdInterceptions(DB.getdInterceptions()+1);

                        RecordGame.database.collection("players").document(pd.getText().toString()).set(DB);
                        RecordGame.database.collection("weeks").document(pd.getText().toString()).update(RecordGame.weekselected + ".dInterceptions", FieldValue.increment(1 ));




                    } else {
                        //
                    }
                } else {
                    //
                }
            }
        });

    }

    public void pick6() {
        doc = RecordGame.database.collection("players").document(pd.getText().toString());
        doc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Player DB = document.toObject(Player.class);
                        DB.setdTD(DB.getdTD()+1);
                        DB.setdInterceptions(DB.getdInterceptions()+1);

                        RecordGame.database.collection("players").document(pd.getText().toString()).set(DB);
                        RecordGame.database.collection("weeks").document(pd.getText().toString()).update(RecordGame.weekselected + ".dInterceptions", FieldValue.increment(1));
                        RecordGame.database.collection("weeks").document(pd.getText().toString()).update(RecordGame.weekselected + ".dTD", FieldValue.increment(1));





                    } else {
                        //
                    }
                } else {
                    //
                }
            }
        });

    }

    public void tackleforloss() {
        if(Integer.valueOf(oyards.getText().toString())<0){
        doc = RecordGame.database.collection("players").document(tackledby.getText().toString());
        doc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Player DB = document.toObject(Player.class);
                        DB.setTacklesForLoss(DB.getTacklesForLoss()+1);


                        RecordGame.database.collection("players").document(tackledby.getText().toString()).set(DB);



                    } else {
                        //
                    }
                } else {
                    //
                }
            }
        });}

    }

    public void td(){
        RecordGame.database.collection("weeks").document("games").update(RecordGame.weekselected + ".teamscore",FieldValue.increment(6))
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        DocumentReference doc = RecordGame.database.collection("weeks").document("games");
                        doc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                if (task.isSuccessful()) {
                                    DocumentSnapshot document = task.getResult();
                                    if (document.exists()) {

                                        HashMap<String, Object> myMap = (HashMap<String, Object>) document.get(RecordGame.weekselected);
                                        Gson gson = new Gson();
                                        JsonElement jsonElement = gson.toJsonTree(myMap);
                                        opponent gameselected = gson.fromJson(jsonElement, opponent.class);
                                        RecordGame.score.setText("Score: LOU "+ gameselected.getTeamscore() + " : " + gameselected.getOpponentscore()+" "+ gameselected.getOpponentabreviation());


                                    } else {
                                        //
                                    }
                                } else {
                                    //
                                }
                            }
                        });
                    }
                });


    }

    public void tdconceded(){
        RecordGame.database.collection("weeks").document("games").update(RecordGame.weekselected + ".opponentscore",FieldValue.increment(6))
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        DocumentReference doc = RecordGame.database.collection("weeks").document("games");
                        doc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                if (task.isSuccessful()) {
                                    DocumentSnapshot document = task.getResult();
                                    if (document.exists()) {

                                        HashMap<String, Object> myMap = (HashMap<String, Object>) document.get(RecordGame.weekselected);
                                        Gson gson = new Gson();
                                        JsonElement jsonElement = gson.toJsonTree(myMap);
                                        opponent gameselected = gson.fromJson(jsonElement, opponent.class);
                                        RecordGame.score.setText("Score: LOU "+ gameselected.getTeamscore() + " : " + gameselected.getOpponentscore()+" "+ gameselected.getOpponentabreviation());


                                    } else {
                                        //
                                    }
                                } else {
                                    //
                                }
                            }
                        });
                    }
                });


    }

    public void fumbleRecovery() {
        doc = RecordGame.database.collection("players").document(fbrecoverer.getText().toString());
        doc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Player fb = document.toObject(Player.class);

                        fb.setdFumblesRecoverd(fb.getdFumblesRecoverd()+1);

                        RecordGame.database.collection("players").document(fbrecoverer.getText().toString()).set(fb);

                        RecordGame.database.collection("weeks").document(fbrecoverer.getText().toString()).update(RecordGame.weekselected + ".dFumblesRecovered", FieldValue.increment(1));



                    } else {
                        //
                    }
                } else {
                    //
                }
            }
        });

    }

    public void restart(){
        restart.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // TODO Auto-generated method stub
                // Begin the transaction
                // Create new fragment and transaction
                Fragment newFragment = new Defense();
                FragmentTransaction transaction = getFragmentManager().beginTransaction();

// Replace whatever is in the fragment_container view with this fragment,
// and add the transaction to the back stack if needed
                transaction.replace(R.id.container, newFragment);
                transaction.addToBackStack(null);

// Commit the transaction
                transaction.commit();
            }
        });
    }

    public void completeplay(){
        RecordGame.database.collection("weeks").document("games").update(RecordGame.weekselected + ".yardsgivenup",FieldValue.increment(Integer.valueOf(oyards.getText().toString())));

    }

    public void offence(){
        restart.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // TODO Auto-generated method stub
                // Begin the transaction
                // Create new fragment and transaction
                Fragment newFragment = new Offence();
                FragmentTransaction transaction = getFragmentManager().beginTransaction();

// Replace whatever is in the fragment_container view with this fragment,
// and add the transaction to the back stack if needed
                transaction.replace(R.id.container, newFragment);
                transaction.addToBackStack(null);

// Commit the transaction
                transaction.commit();
            }
        });
    }
}
