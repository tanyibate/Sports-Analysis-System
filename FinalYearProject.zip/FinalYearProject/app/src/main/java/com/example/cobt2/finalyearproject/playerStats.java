package com.example.cobt2.finalyearproject;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.Calendar;

public class playerStats extends AppCompatActivity {

    FragmentPagerAdapter adapterViewPager;
    static String playerselected;
    static String playerposition;
    Player player;
    static FirebaseFirestore database;
    TextView age,name,height,weight,dob,fourty,jersey;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        database = FirebaseFirestore.getInstance();
        Intent intent = getIntent();
        playerselected = intent.getStringExtra("number");









        database = FirebaseFirestore.getInstance();

        DocumentReference docRef = database.collection("players").document(playerselected);
        docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        age = findViewById(R.id.age);
                        fourty = findViewById(R.id.fourty);
                        name = findViewById(R.id.name);
                        weight = findViewById(R.id.weight);
                        jersey = findViewById(R.id.jersey);
                        height = findViewById(R.id.height);
                        dob = findViewById(R.id.birthdate);
                        Player upload = document.toObject(Player.class);
                        playerposition = upload.getPosition();
                        ViewPager vpPager = (ViewPager) findViewById(R.id.vpPager);
                        adapterViewPager = new MyPagerAdapter(getSupportFragmentManager());
                        vpPager.setAdapter(adapterViewPager);
                        name.setText(upload.getName());
                        height.setText("Height: "+ upload.getFeet()+"'"+upload.getInches()+'"');
                        weight.setText("Weight: " + upload.getWeight()+"lbs");
                        jersey.setText("Jersey #"+upload.getNumber());
                        fourty.setText("40: "+upload.getForty()+" sec");
                        Calendar c = Calendar.getInstance();
                        String strdate = null;
                        c.set(upload.getYear(),upload.getMonth(),upload.getDay());
                        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

                        if (c != null) {
                            strdate = sdf.format(c.getTime());
                        }
                        dob.setText("Birth Date: " + strdate);
                        age.setText("Age: "+ getAge(upload.getYear(),upload.getMonth(),upload.getDay())+" Years");




                    } else {
                        //
                    }
                } else {
                    //
                }
            }
        });



        setContentView(R.layout.activity_player_stats);


    }



    public static class MyPagerAdapter extends FragmentPagerAdapter {
        private static int NUM_ITEMS = 4;

        public MyPagerAdapter(FragmentManager fragmentManager) {
            super(fragmentManager);
        }

        // Returns total number of pages
        @Override
        public int getCount() {
            return NUM_ITEMS;
        }

        // Returns the fragment to display for that page
        @Override
        public Fragment getItem(int position) {
            switch (position) {
                case 0: // Fragment # 0 - This will show FirstFragment

                    if(playerposition.equals("Quarterback")){
                        return FirstFragment.newInstance(1, "Page # 2",playerselected);

                    }

                    else if(playerposition.equals("Strong Safety") || playerposition.equals("Free Safety")|| playerposition.equals("Cornerback")){
                        return DBStats.newInstance(1, "Page # 2",playerselected);

                    }

                    else if(playerposition.equals("Middle Linebacker") || playerposition.equals("Outside Linebacker")){
                        return LinebackerStats.newInstance(1, "Page # 2",playerselected);

                    }

                    else if(playerposition.equals("Defensive End") || playerposition.equals("Defensive Tackle")){
                        return LinebackerStats.newInstance(1, "Page # 2",playerselected);

                    }

                    else if(playerposition.equals("Wide Receiver") || playerposition.equals("Slot Receiver")){
                        return ReceiverStats.newInstance(1, "Page # 2",playerselected);

                    }
                    else if(playerposition.equals("Tailback") || playerposition.equals("Fullback") || playerposition.equals("Halveback") || playerposition.equals("Wingback") || playerposition.equals("Tailback")){
                        return RunningBackStats.newInstance(1, "Page # 2",playerselected);

                    }




                    else return ratingGraph.newInstance(0, "Page # 1",playerselected);

                case 1: // Fragment # 0 - This will show FirstFragment different title
                    if(playerposition.equals("Quarterback")){
                        return SecondFragment.newInstance(1, "Page # 2",playerselected);

                    }

                    else if(playerposition.equals("Strong Safety") || playerposition.equals("Free Safety")|| playerposition.equals("Cornerback")){
                        return DBTable.newInstance(1, "Page # 2",playerselected);

                    }

                    else if(playerposition.equals("Middle Linebacker") || playerposition.equals("Outside Linebacker")){
                        return LinebackerTable.newInstance(1, "Page # 2",playerselected);

                    }

                    else if(playerposition.equals("Defensive End") || playerposition.equals("Defensive Tackle")){
                        return DLineTable.newInstance(1, "Page # 2",playerselected);

                    }

                    else if(playerposition.equals("Wide Receiver") || playerposition.equals("Slot Receiver")){
                        return ReceiverTable.newInstance(1, "Page # 2",playerselected);

                    }
                    else if(playerposition.equals("Tailback") || playerposition.equals("Fullback") || playerposition.equals("Halveback") || playerposition.equals("Wingback") || playerposition.equals("Tailback")){
                        return RunningBackTable.newInstance(1, "Page # 2",playerselected);

                    }




                    else return allStats.newInstance(0, "Page # 1",playerselected);


                case 2: // Fragment # 1 - This will show SecondFragment
                    return ratingGraph.newInstance(2, "Page # 3",playerselected);
                case 3: // Fragment # 1 - This will show SecondFragment

                    return allStats.newInstance(3, "Page # 4",playerselected);
                default:
                    return null;
            }
        }

        // Returns the page title for the top indicator
        @Override
        public CharSequence getPageTitle(int position) {
            return "Page " + position;
        }

    }

    private String getAge(int year, int month, int day){
        Calendar dob = Calendar.getInstance();
        Calendar today = Calendar.getInstance();

        dob.set(year, month, day);

        int age = today.get(Calendar.YEAR) - dob.get(Calendar.YEAR);

        if (today.get(Calendar.DAY_OF_YEAR) < dob.get(Calendar.DAY_OF_YEAR)){
            age--;
        }

        Integer ageInt = new Integer(age);
        String ageS = ageInt.toString();

        return ageS;
    }
}
