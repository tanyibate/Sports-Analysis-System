package com.example.cobt2.finalyearproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class OptionScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_option_screen);

    }

    public void players(View view) {



            Intent optionIntent = new Intent(OptionScreen.this ,Players.class);
            startActivity(optionIntent);




    }

    public void games(View view) {



        Intent optionIntent = new Intent(OptionScreen.this ,gameweek.class);
        startActivity(optionIntent);




    }

    public void users(View view) {



        Intent optionIntent = new Intent(OptionScreen.this ,Users.class);
        startActivity(optionIntent);




    }

    public void coaches(View view) {



        Intent optionIntent = new Intent(OptionScreen.this ,Coaches.class);
        startActivity(optionIntent);




    }
}
