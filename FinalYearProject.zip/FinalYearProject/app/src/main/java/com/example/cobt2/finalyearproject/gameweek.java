package com.example.cobt2.finalyearproject;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;
import com.google.gson.Gson;
import com.google.gson.JsonElement;

import java.util.ArrayList;
import java.util.HashMap;


public class gameweek extends AppCompatActivity {

    ListView listView;
    public static ArrayList<HashMap<String, String>> list;
    public static final String FIRST_COLUMN="First";
    public static final String SECOND_COLUMN="Second";
    public static final String THIRD_COLUMN="Third";
    public static final String FOURTH_COLUMN="Fourth";
    static ListViewAdapter2 adapter;
    String weekselected;
    String opponentselected;
    Toast toastMessage;
    static double numberofgames;
    static EditText opponent;
    static EditText opponentabreviation;
    opponent gameselected;
    Button select;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gameweek);

        listView=(ListView)findViewById(R.id.listView1);
        populateList();
        opponent = findViewById(R.id.opponent);
        opponentabreviation = findViewById(R.id.opponentabreviation);
        select = findViewById(R.id.select);

        adapter =new ListViewAdapter2(this, list);
        listView.setAdapter(adapter);
        final TextView gameselected1 = findViewById(R.id.gameselected);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                TextView textView = (TextView) view.findViewById(R.id.TextFirst);
                TextView textView2 = (TextView) view.findViewById(R.id.TextSecond);
                TextView textView3 = (TextView) view.findViewById(R.id.TextSecond);


                weekselected = textView.getText().toString();
                opponentselected = textView2.getText().toString();

                gameselected1.setText("Game Selected: Week"+weekselected+" vs "+opponentselected);
                if (toastMessage!= null) {
                    toastMessage.cancel();
                }

                toastMessage.makeText(getApplicationContext(), "Game Selected: Week"+weekselected+" vs "+opponentselected, Toast.LENGTH_SHORT).show();


                final FirebaseFirestore database = FirebaseFirestore.getInstance();

                DocumentReference doc = database.collection("weeks").document("games");
                doc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) {
                            DocumentSnapshot document = task.getResult();
                            if (document.exists()) {

                                HashMap<String, Object> myMap = (HashMap<String, Object>) document.get(weekselected);
                                Gson gson = new Gson();
                                JsonElement jsonElement = gson.toJsonTree(myMap);
                                gameselected = gson.fromJson(jsonElement, opponent.class);
                                if(gameselected.isPlayed()==false){
                                    select.setVisibility(View.VISIBLE);
                                    select.setOnClickListener(new View.OnClickListener() {
                                        public void onClick(View v) {
                                            // Code here executes on main thread after user presses button
                                            select();
                                        }
                                    });

                                }
                                else {
                                    select.setVisibility(View.INVISIBLE);
                                }



                                TextView score = findViewById(R.id.score);
                                TextView offensiveturnovers = findViewById(R.id.tunroversonoffense);
                                TextView defensiveturnovers = findViewById(R.id.turnoversondefense);
                                TextView turnoverdifferential = findViewById(R.id.turnoverdifferential);
                                TextView yardsgained = findViewById(R.id.yardsgained);
                                TextView yardsgivenup = findViewById(R.id.yardsgivenup);
                                score.setText("Score: LOU "+ gameselected.getTeamscore() + " : " + gameselected.getOpponentscore()+" "+ gameselected.getOpponentabreviation());
                                offensiveturnovers.setText("Turnovers on Offence: "+Integer.toString(gameselected.getOffensiveturnovers()));
                                defensiveturnovers.setText("Turnovers on Defense: "+ Integer.toString(gameselected.getDefensiveturnovers()));
                                turnoverdifferential.setText("Turnover Differential: " +Integer.toString((gameselected.getDefensiveturnovers()-gameselected.getOffensiveturnovers())));
                                yardsgained.setText("Yards Gained: "+ Integer.toString(gameselected.getYardsgained()));
                                yardsgivenup.setText("Yards Given Up: "+ Integer.toString(gameselected.getYardsgivenup()));

















                            } else {
                                //
                            }
                        } else {
                            //
                        }
                    }
                });


//where list_content is the id of TextView in listview_item.xml

            }});
    }

    public static void populateList() {
        // TODO Auto-generated method stub

        list=new ArrayList<HashMap<String,String>>();


        final FirebaseFirestore database = FirebaseFirestore.getInstance();


        DocumentReference doc = database.collection("weeks").document("games");
        doc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {

                        numberofgames = document.getDouble("numberofgames");
                        for(int i=1;i<=numberofgames;i++) {

                            HashMap<String, Object> myMap = (HashMap<String, Object>) document.get(Integer.toString(i));
                            Gson gson = new Gson();
                            JsonElement jsonElement = gson.toJsonTree(myMap);
                            opponent upload = gson.fromJson(jsonElement, opponent.class);


                            final String number = Integer.toString(i);


                                            HashMap<String, String> hashmap4 = new HashMap<String, String>();
                                            hashmap4.put(FIRST_COLUMN, number);
                                            hashmap4.put(SECOND_COLUMN,upload.getOpponent() );
                                            if(upload.isPlayed()==false){
                                                hashmap4.put(THIRD_COLUMN, "To be Played");
                                            }
                                            else{
                                                hashmap4.put(THIRD_COLUMN, "LOU "+ upload.getTeamscore() + " : " + upload.getOpponentscore()+" "+ upload.getOpponentabreviation());
                                            }

                                            hashmap4.put(FOURTH_COLUMN, "App");
                                            list.add(hashmap4);



                        }




















                    } else {
                        //
                    }
                } else {
                    //
                }
            }
        });







    }


    public static void addGame(View view) {


        final opponent team = new opponent();
        team.setOpponent(opponent.getText().toString());
        team.setOpponentabreviation(opponentabreviation.getText().toString());


        final FirebaseFirestore database = FirebaseFirestore.getInstance();


        DocumentReference doc = database.collection("weeks").document("games");
        doc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {

                        HashMap<String,String> hashmap=new HashMap<String, String>();
                        final int  first= (int) numberofgames;
                        hashmap.put(FIRST_COLUMN,Integer.toString(((first+1))));
                        hashmap.put(SECOND_COLUMN,team.getOpponent());
                        hashmap.put(THIRD_COLUMN,"To be Played");
                        list.add(hashmap);
                        adapter.notifyDataSetChanged();
                        //User user = new User(name,number,pos);
                        HashMap<String,opponent> map = new HashMap<>();
                        map.put(Integer.toString(first+1),team);
                        database.collection("weeks").document("games").set(map, SetOptions.merge());


                        database.collection("weeks").document("games").update("numberofgames",first+1);
                        for(int i=0;i<100;i++){


                            final String number = Integer.toString(i);

                            DocumentReference docRef = database.collection("players").document(Integer.toString(i));

                            final int finalI = i;
                            docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                @Override
                                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                    if (task.isSuccessful()) {
                                        DocumentSnapshot document = task.getResult();
                                        if (document.exists()) {
                                            Player player = document.toObject(Player.class);
                                            playerGameWeek player2 = new playerGameWeek();
                                            player2.setNumber(player.getNumber());
                                            player2.setOpponent(team.getOpponentabreviation());
                                            HashMap<String,playerGameWeek> map = new HashMap<>();
                                            map.put(Integer.toString(first+1),player2);
                                            database.collection("weeks").document(Integer.toString(finalI)).set(map, SetOptions.merge());







                                        } else {
                                            //
                                        }
                                    } else {
                                        //
                                    }
                                }
                            });}




                    } else {
                        //
                    }
                } else {
                    //
                }
            }
        });

    }


    public void select(){




        Intent selectIntent = new Intent(gameweek.this ,RecordGame.class);
        selectIntent.putExtra("week",weekselected);

        startActivity(selectIntent);




    }
}
