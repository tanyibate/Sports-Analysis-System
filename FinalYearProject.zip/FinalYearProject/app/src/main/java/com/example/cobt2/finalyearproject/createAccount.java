package com.example.cobt2.finalyearproject;

import android.content.Intent;
import android.support.annotation.IdRes;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

public class createAccount extends AppCompatActivity {

    Button register;
    EditText firstname;
    EditText lastname;
    EditText username;
    EditText password;
    EditText confirmpassword;
    EditText registrationnumber;
    FirebaseFirestore db;
    boolean complete = false;
    RadioGroup usertype;
    String option;
    boolean inSystem = false;
    EditText jerseynumber;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_create_account);
        register = findViewById(R.id.createaccount);
        firstname = findViewById(R.id.firstname);
        lastname = findViewById(R.id.lastname);
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        confirmpassword = findViewById(R.id.confirmpassword);
        registrationnumber = findViewById(R.id.number);
        usertype = findViewById(R.id.usertype);
        jerseynumber = findViewById(R.id.jerseynumber);
        db = FirebaseFirestore.getInstance();




        usertype.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, @IdRes int checkedId) {
                RadioButton rb= (RadioButton) findViewById(checkedId);
                option = rb.getText().toString();
                Log.d(option,option);
            }
        });

        register.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                // Code here executes on main thread after user presses button

                    if(option.equals("Player")){
                       playerRegistration();
                    }
                    else {
                        coachRegistration();
                    }

                }


        });

    }

    public void coachRegistration(){
        db.collection("coaches")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                Log.d("hello", String.valueOf(document.get("uniqueID")));

                                if(Double.valueOf(registrationnumber.getText().toString()).equals(document.getDouble("uniqueID"))){
                                    inSystem = true;
                                    User user = new User();
                                    user.setFirstname(firstname.getText().toString());
                                    user.setLastname(lastname.getText().toString());
                                    user.setPassword(password.getText().toString());
                                    user.setUsername(username.getText().toString());
                                    user.setRegistrationnumber(registrationnumber.getText().toString());
                                    user.setUserType(option);
                                    db.collection("users").document(username.getText().toString()).set(user);
                                    //user.setNumber(Integer.valueOf(jerseynumber.getText().toString()));
                                }

                            }
                            if(inSystem==true){

                                Intent login = new Intent(createAccount.this,HomeActivity.class);
                                startActivity(login);
                            }
                        } else {

                        }
                    }
                });
    }

    public void playerRegistration(){
        db.collection("players")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                Log.d("hello", String.valueOf(document.get("uniqueID")));

                                if(Double.valueOf(registrationnumber.getText().toString()).equals(document.getDouble("uniqueID"))){
                                    inSystem = true;
                                    User user = new User();
                                    user.setFirstname(firstname.getText().toString());
                                    user.setLastname(lastname.getText().toString());
                                    user.setPassword(password.getText().toString());
                                    user.setUsername(username.getText().toString());
                                    user.setRegistrationnumber(registrationnumber.getText().toString());
                                    user.setUserType(option);
                                    db.collection("users").document(username.getText().toString()).set(user);
                                    //user.setNumber(Integer.valueOf(jerseynumber.getText().toString()));
                                }

                            }
                            if(inSystem==true){

                                Intent login = new Intent(createAccount.this,HomeActivity.class);
                                startActivity(login);
                            }
                        } else {

                        }
                    }
                });
    }






}
