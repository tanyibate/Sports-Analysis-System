package com.example.cobt2.finalyearproject;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.gson.Gson;
import com.google.gson.JsonElement;

import java.util.HashMap;


public class twopointconversion extends Fragment {

    Button defense;
    Button penalty;
    Button fieldgoal;
    Button punt;
    Button setpasserinplay;
    Button passersacked;
    Button setRusher;
    Button passCompleted;
    Button incompletePass;
    Button interception;
    Button rushingTD;
    Button pick6;
    Button passingTD;
    Button fumbleRecovery;
    Button completePlay;
    Button fbRTouchdown;
    Button fumblelost;
    EditText passer;
    EditText rusher;
    EditText receiver;
    EditText startingposition;
    EditText penaltyyards;
    EditText rushingyardsgained;
    EditText passingyardsgained;
    EditText totalyardsgained;
    EditText yardsgained;
    EditText fumbler;
    Button restart;
    DocumentReference doc;








    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    // The onCreateView method is called when Fragment should create its View object hierarchy,
    // either dynamically or via XML layout inflation.
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup parent, Bundle savedInstanceState) {
        // Defines the xml file for the fragment
        return inflater.inflate(R.layout.fragment_twopointconversion, parent, false);
    }

    // This event is triggered soon after onCreateView().
    // Any view setup should occur here.  E.g., view lookups and attaching view listeners.
    @Override
    public void onViewCreated(final View view, Bundle savedInstanceState) {

        penalty =view.findViewById(R.id.penalty);
        passingTD = view.findViewById(R.id.passingtd);
        passingTD.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                passcompleteted();
                pointgood();
                Toast.makeText(view.getContext(),"2pt good",Toast.LENGTH_SHORT).show();
                // Code here executes on main thread after user presses button
            }
        });


        punt = view.findViewById(R.id.punt);
        completePlay = view.findViewById(R.id.completeplay);
        completePlay.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                completeplay();
                Toast.makeText(view.getContext(),"Play Completed",Toast.LENGTH_SHORT).show();
                // Code here executes on main thread after user presses button
            }
        });
        setRusher = view.findViewById(R.id.setrusher);
        passCompleted = view.findViewById(R.id.passcompleted);
        passCompleted.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                passcompleteted();
                passreceived();
                Toast.makeText(view.getContext(),"Pass Completed",Toast.LENGTH_SHORT).show();

                // Code here executes on main thread after user presses button
            }
        });


        incompletePass = view.findViewById(R.id.incompletepass);
        incompletePass.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                passincompleteted();
                Toast.makeText(view.getContext(),"Pass Incompleted",Toast.LENGTH_SHORT).show();

                // Code here executes on main thread after user presses button
            }
        });
        rushingTD = view.findViewById(R.id.rushingtouchdown);
        rushingTD.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                rush();
                pointgood();
                Toast.makeText(view.getContext(),"2pt good",Toast.LENGTH_SHORT).show();

                // Code here executes on main thread after user presses button
            }
        });
        pick6 = view.findViewById(R.id.pick6);
        pick6.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                interceptionThrown();
                safety();
                Toast.makeText(view.getContext(),"Pick 6",Toast.LENGTH_SHORT).show();

                // Code here executes on main thread after user presses button
            }
        });
        fumblelost = view.findViewById(R.id.fumblelost);
        fumblelost.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                fumbleLost();
                Toast.makeText(view.getContext(),"Fumble",Toast.LENGTH_SHORT).show();

                // Code here executes on main thread after user presses button
            }
        });
        fumbleRecovery = view.findViewById(R.id.fumblerecovery);
        fumbleRecovery.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                fumbleRecovery();
                Toast.makeText(view.getContext(),"Fumble Recovered",Toast.LENGTH_SHORT).show();

                // Code here executes on main thread after user presses button
            }
        });
        fbRTouchdown = view.findViewById(R.id.fumblerecoverytouchdown);
        fbRTouchdown.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                fumbleRecovery();
                pointgood();
                // Code here executes on main thread after user presses button
            }
        });
        restart = view.findViewById(R.id.restart);
        restart.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                restart();
                // Code here executes on main thread after user presses button
            }
        });
        penalty = view.findViewById(R.id.penalty);
        passer = view.findViewById(R.id.passerinplay);
        rusher = view.findViewById(R.id.rusher);
        rushingyardsgained = view.findViewById(R.id.rushingyardsgained);
        passingyardsgained = view.findViewById(R.id.passingyardsgained);
        receiver = view.findViewById(R.id.receiver);
        penaltyyards = view.findViewById(R.id.penaltyards);
        fumbler = view.findViewById(R.id.fumbler);
        yardsgained = view.findViewById(R.id.yardsgained);
        interception = view.findViewById(R.id.interception);
        interception.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                interceptionThrown();
                Toast.makeText(view.getContext(),"Interception",Toast.LENGTH_SHORT).show();

                // Code here executes on main thread after user presses button
            }
        });






        // Setup any handles to view objects here
        // EditText etFoo = (EditText) view.findViewById(R.id.etFoo);
    }

    public void passcompleteted() {
        doc = RecordGame.database.collection("players").document(passer.getText().toString());
        doc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Player passerInPlay = document.toObject(Player.class);
                        passerInPlay.setPassesCompleted(passerInPlay.getPassesCompleted()+1);
                        passerInPlay.setPassesAttempted(passerInPlay.getPassesAttempted()+1);
                        passerInPlay.setPassingYards(passerInPlay.getPassingYards() + Integer.valueOf(passingyardsgained.getText().toString()));
                        RecordGame.database.collection("players").document(passer.getText().toString()).set(passerInPlay);
                        RecordGame.database.collection("weeks").document(passer.getText().toString()).update(RecordGame.weekselected + ".passesCompleted", FieldValue.increment(1));
                        RecordGame.database.collection("weeks").document(passer.getText().toString()).update(RecordGame.weekselected + ".passingYards", FieldValue.increment(Integer.valueOf(passingyardsgained.getText().toString())));
                        RecordGame.database.collection("weeks").document(passer.getText().toString()).update(RecordGame.weekselected + ".passingYards", FieldValue.increment(Integer.valueOf(passingyardsgained.getText().toString())));



                    } else {
                        //
                    }
                } else {
                    //
                }
            }
        });

    }

    public void passTD() {
        doc = RecordGame.database.collection("players").document(passer.getText().toString());
        doc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Player passerInPlay = document.toObject(Player.class);
                        passerInPlay.setPassesCompleted(passerInPlay.getPassesCompleted()+1);
                        passerInPlay.setPassesAttempted(passerInPlay.getPassesAttempted()+1);
                        passerInPlay.setPassingYards(passerInPlay.getPassingYards() + Integer.valueOf(passingyardsgained.getText().toString()));
                        passerInPlay.setPassingTD(passerInPlay.getPassingTD()+1);
                        RecordGame.database.collection("players").document(passer.getText().toString()).set(passerInPlay);
                        RecordGame.database.collection("weeks").document(passer.getText().toString()).update(RecordGame.weekselected + ".passesCompleted", FieldValue.increment(1));
                        RecordGame.database.collection("weeks").document(passer.getText().toString()).update(RecordGame.weekselected + ".passesAttempted", FieldValue.increment(1));
                        RecordGame.database.collection("weeks").document(passer.getText().toString()).update(RecordGame.weekselected + ".passingTD", FieldValue.increment(1));
                        RecordGame.database.collection("weeks").document(passer.getText().toString()).update(RecordGame.weekselected + ".passingYards", FieldValue.increment(Integer.valueOf(passingyardsgained.getText().toString())));



                    } else {
                        //
                    }
                } else {
                    //
                }
            }
        });

    }



    public void interceptionThrown() {
        doc = RecordGame.database.collection("players").document(passer.getText().toString());
        doc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Player passerInPlay = document.toObject(Player.class);
                        passerInPlay.setInterceptions(passerInPlay.getInterceptions()+1);
                        passerInPlay.setPassesAttempted(passerInPlay.getPassesAttempted()+1);

                        RecordGame.database.collection("players").document(passer.getText().toString()).set(passerInPlay);
                        RecordGame.database.collection("weeks").document(passer.getText().toString()).update(RecordGame.weekselected + ".passesAttempted", FieldValue.increment(1));
                        RecordGame.database.collection("weeks").document(passer.getText().toString()).update(RecordGame.weekselected + ".interceptions", FieldValue.increment(1));



                    } else {
                        //
                    }
                } else {
                    //
                }
            }
        });

    }

    public void fumbleLost() {
        doc = RecordGame.database.collection("players").document(fumbler.getText().toString());
        doc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Player fb = document.toObject(Player.class);
                        fb.setFumblesLost(fb.getFumblesLost()+1);
                        fb.setFumbles(fb.getFumbles()+1);

                        RecordGame.database.collection("players").document(fumbler.getText().toString()).set(fb);
                        RecordGame.database.collection("weeks").document(fumbler.getText().toString()).update(RecordGame.weekselected + ".fumblesLost", FieldValue.increment(1));
                        RecordGame.database.collection("weeks").document(fumbler.getText().toString()).update(RecordGame.weekselected + ".fumbles", FieldValue.increment(1));



                    } else {
                        //
                    }
                } else {
                    //
                }
            }
        });

    }

    public void fumbleRecovery() {
        doc = RecordGame.database.collection("players").document(fumbler.getText().toString());
        doc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Player fb = document.toObject(Player.class);

                        fb.setFumbles(fb.getFumbles()+1);

                        RecordGame.database.collection("players").document(fumbler.getText().toString()).set(fb);

                        RecordGame.database.collection("weeks").document(fumbler.getText().toString()).update(RecordGame.weekselected + ".fumbles", FieldValue.increment(1));



                    } else {
                        //
                    }
                } else {
                    //
                }
            }
        });

    }







    public void passincompleteted() {
        doc = RecordGame.database.collection("players").document(passer.getText().toString());
        doc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Player passerInPlay = document.toObject(Player.class);

                        passerInPlay.setPassesAttempted(passerInPlay.getPassesAttempted()+1);
                        RecordGame.database.collection("players").document(passer.getText().toString()).set(passerInPlay);
                        RecordGame.database.collection("weeks").document(passer.getText().toString()).update(RecordGame.weekselected + ".passesAttempted", FieldValue.increment(1));



                    } else {
                        //
                    }
                } else {
                    //
                }
            }
        });

    }

    public void passreceived() {
        doc = RecordGame.database.collection("players").document(receiver.getText().toString());
        doc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Player rcv = document.toObject(Player.class);

                        rcv.setPassesCaught(rcv.getPassesCaught()+1);
                        RecordGame.database.collection("weeks").document(receiver.getText().toString()).update(RecordGame.weekselected + ".passesCaught", FieldValue.increment(1));
                        if(rcv.getLongestReception()<Integer.valueOf(passingyardsgained.getText().toString()))
                        {

                            rcv.setLongestReception(Integer.valueOf(passingyardsgained.getText().toString()));
                        }
                        RecordGame.database.collection("players").document(receiver.getText().toString()).set(rcv);




                    } else {
                        //
                    }
                } else {
                    //
                }
            }
        });

    }

    /*public void passreceivedTD() {
        doc = RecordGame.database.collection("players").document(receiver.getText().toString());
        doc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Player rcv = document.toObject(Player.class);

                        rcv.setPassesCaught(rcv.getPassesCaught()+1);
                        RecordGame.database.collection("weeks").document(receiver.getText().toString()).update(RecordGame.weekselected + ".passesCaught", FieldValue.increment(1));
                        RecordGame.database.collection("weeks").document(receiver.getText().toString()).update(RecordGame.weekselected + ".receivingTD", FieldValue.increment(1));
                        if(rcv.getLongestReception()<Integer.valueOf(passingyardsgained.getText().toString()))
                        {

                            rcv.setLongestReception(Integer.valueOf(passingyardsgained.getText().toString()));
                            RecordGame.database.collection("weeks").document(receiver.getText().toString()).update(RecordGame.weekselected + ".longestReception",FieldValue.increment(Integer.valueOf(passingyardsgained.getText().toString()) ));
                        }
                        RecordGame.database.collection("players").document(receiver.getText().toString()).set(rcv);



                    } else {
                        //
                    }
                } else {
                    //
                }
            }
        });

    }*/

    public void rush() {
        doc = RecordGame.database.collection("players").document(rusher.getText().toString());
        doc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Player rushers = document.toObject(Player.class);
                        rushers.setRushingYards(rushers.getRushingYards()+(Integer.valueOf(rushingyardsgained.getText().toString())));

                        rushers.setCarries(rushers.getCarries()+1);
                        rushers.setYardsPerCarry();
                        RecordGame.database.collection("players").document(rusher.getText().toString()).set(rushers);
                        RecordGame.database.collection("weeks").document(rusher.getText().toString()).update(RecordGame.weekselected + ".rushingYards",FieldValue.increment(Integer.valueOf(rushingyardsgained.getText().toString()) ));
                        RecordGame.database.collection("weeks").document(rusher.getText().toString()).update(RecordGame.weekselected + ".carries",FieldValue.increment(1));





                    } else {
                        //
                    }
                } else {
                    //
                }
            }
        });

    }

    public void rushtd() {
        doc = RecordGame.database.collection("players").document(rusher.getText().toString());
        doc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Player rushers = document.toObject(Player.class);
                        rushers.setRushingYards(rushers.getRushingYards()+(Integer.valueOf(rushingyardsgained.getText().toString())));

                        rushers.setCarries(rushers.getCarries()+1);
                        rushers.setRushingTD(rushers.getRushingTD()+1);
                        rushers.setYardsPerCarry();
                        RecordGame.database.collection("players").document(rusher.getText().toString()).set(rushers);
                        RecordGame.database.collection("weeks").document(rusher.getText().toString()).update(RecordGame.weekselected + ".rushingYards",FieldValue.increment(Integer.valueOf(rushingyardsgained.getText().toString()) ));
                        RecordGame.database.collection("weeks").document(rusher.getText().toString()).update(RecordGame.weekselected + ".carries",FieldValue.increment(1));
                        RecordGame.database.collection("weeks").document(rusher.getText().toString()).update(RecordGame.weekselected + ".rushingTD",FieldValue.increment(1));







                    } else {
                        //
                    }
                } else {
                    //
                }
            }
        });

    }

    public void completeplay(){
        RecordGame.database.collection("weeks").document("games").update(RecordGame.weekselected + ".yardsgained",FieldValue.increment(Integer.valueOf(yardsgained.getText().toString())));

    }

    public void pointgood(){
        RecordGame.database.collection("weeks").document("games").update(RecordGame.weekselected + ".teamscore",FieldValue.increment(2))
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        DocumentReference doc = RecordGame.database.collection("weeks").document("games");
                        doc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                if (task.isSuccessful()) {
                                    DocumentSnapshot document = task.getResult();
                                    if (document.exists()) {

                                        HashMap<String, Object> myMap = (HashMap<String, Object>) document.get(RecordGame.weekselected);
                                        Gson gson = new Gson();
                                        JsonElement jsonElement = gson.toJsonTree(myMap);
                                        opponent gameselected = gson.fromJson(jsonElement, opponent.class);
                                        RecordGame.score.setText("Score: LOU "+ gameselected.getTeamscore() + " : " + gameselected.getOpponentscore()+" "+ gameselected.getOpponentabreviation());


                                    } else {
                                        //
                                    }
                                } else {
                                    //
                                }
                            }
                        });
                    }
                });


    }

    public void safety(){
        RecordGame.database.collection("weeks").document("games").update(RecordGame.weekselected + ".opponentscore",FieldValue.increment(2))
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        DocumentReference doc = RecordGame.database.collection("weeks").document("games");
                        doc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                if (task.isSuccessful()) {
                                    DocumentSnapshot document = task.getResult();
                                    if (document.exists()) {

                                        HashMap<String, Object> myMap = (HashMap<String, Object>) document.get(RecordGame.weekselected);
                                        Gson gson = new Gson();
                                        JsonElement jsonElement = gson.toJsonTree(myMap);
                                        opponent gameselected = gson.fromJson(jsonElement, opponent.class);
                                        RecordGame.score.setText("Score: LOU "+ gameselected.getTeamscore() + " : " + gameselected.getOpponentscore()+" "+ gameselected.getOpponentabreviation());


                                    } else {
                                        //
                                    }
                                } else {
                                    //
                                }
                            }
                        });
                    }
                });


    }

    public void restart(){
        restart.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // TODO Auto-generated method stub
                // Begin the transaction
                // Create new fragment and transaction
                Fragment newFragment = new twopointconversion();
                FragmentTransaction transaction = getFragmentManager().beginTransaction();

// Replace whatever is in the fragment_container view with this fragment,
// and add the transaction to the back stack if needed
                transaction.replace(R.id.container, newFragment);
                transaction.addToBackStack(null);

// Commit the transaction
                transaction.commit();
            }
        });
    }

    public void punt(){
        restart.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // TODO Auto-generated method stub
                // Begin the transaction
                // Create new fragment and transaction
                Fragment newFragment = new punt();
                FragmentTransaction transaction = getFragmentManager().beginTransaction();

// Replace whatever is in the fragment_container view with this fragment,
// and add the transaction to the back stack if needed
                transaction.replace(R.id.container, newFragment);
                transaction.addToBackStack(null);

// Commit the transaction
                transaction.commit();
            }
        });
    }










}
