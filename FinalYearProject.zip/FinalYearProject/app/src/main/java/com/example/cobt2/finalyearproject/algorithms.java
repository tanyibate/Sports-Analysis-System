package com.example.cobt2.finalyearproject;

public class algorithms {

    public static Double passerRating(int completions,int att, int td, int interceptions,int yards){
        double passerRating;
        double a = ((completions/att) - 0.3)*5;
        double b = ((yards/att) - 3)*0.25;
        double c = (td/att)*20;
        double d = 2.375 - ((interceptions/att) * 25);

        passerRating =((a+b+c+d)/6)*100;

        return passerRating;


    }
}
