package com.example.cobt2.finalyearproject;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.gson.Gson;
import com.google.gson.JsonElement;

import java.util.ArrayList;
import java.util.HashMap;


public class LinebackerTable extends Fragment {
    // Store instance variables
    private String title;
    private int page;
    playerGameWeek player;

    int games = 0;
    boolean documentexist = false;
    DocumentReference doc;
    String number;
    ArrayList<playerGameWeek> gameweeks = new ArrayList<>();
    String name;


    // newInstance constructor for creating fragment with arguments
    public static LinebackerTable newInstance(int page, String title, String playerselected) {
        LinebackerTable fragmentFirst = new LinebackerTable();
        Bundle args = new Bundle();
        args.putInt("someInt", page);
        args.putString("someTitle", title);
        args.putString("number",playerselected);
        fragmentFirst.setArguments(args);
        return fragmentFirst;
    }

    // Store instance variables based on arguments passed
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        page = getArguments().getInt("someInt", 0);
        title = getArguments().getString("someTitle");
        number = getArguments().getString("number");



    }

    // Inflate the view for the fragment based on layout XML
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_second, container, false);
        // Setup any handles to view objects here
        // EditText etFoo = (EditText) view.findViewById(R.id.etFoo);

        //TableRow firstrow = new TableRow(view.getContext());



        DocumentReference docRef = Players.db.collection("weeks").document("games");
        docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {

                        games = document.getDouble("numberofgames").intValue();




                    } else {

                        //
                    }
                } else {
                    //
                }
            }
        });









        return view;

    }

    public void onViewCreated(final View view, Bundle savedInstanceState) {

        final TableLayout table = view.findViewById(R.id.table);






            //FirebaseFirestore dbe = FirebaseFirestore.getInstance();
            DocumentReference docRef = Players.db.collection("weeks").document(number);

            docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                    if (task.isSuccessful()) {
                        DocumentSnapshot document = task.getResult();
                        if (document.exists()) {


                            for(int i=1;i<=games;i++) {

                                if (document.get(Integer.toString(i)) != null) {




                                HashMap<String, Object> myMap = (HashMap<String, Object>) document.get(Integer.toString(i));
                                Gson gson = new Gson();
                                JsonElement jsonElement = gson.toJsonTree(myMap);
                                playerGameWeek player = gson.fromJson(jsonElement, playerGameWeek.class);


                                TableRow row = new TableRow(view.getContext());


                                TextView week = new android.support.v7.widget.AppCompatTextView(view.getContext()) {
                                    @Override
                                    protected void onDraw(Canvas canvas) {
                                        super.onDraw(canvas);
                                        Rect rect = new Rect();
                                        Paint paint = new Paint();
                                        paint.setStyle(Paint.Style.STROKE);
                                        paint.setColor(Color.WHITE);
                                        paint.setStrokeWidth(2);
                                        getLocalVisibleRect(rect);
                                        canvas.drawRect(rect, paint);
                                    }

                                };
                                TableRow.LayoutParams params2 = new TableRow.LayoutParams(40, 47, 1f);
                                week.setLayoutParams(params2);
                                week.setTextSize(24);

                                week.setText(Integer.toString(i));
                                week.setPadding(6, 4, 6, 4);
                                row.addView(week);

                                TextView opponent = new android.support.v7.widget.AppCompatTextView(view.getContext()) {
                                    @Override
                                    protected void onDraw(Canvas canvas) {
                                        super.onDraw(canvas);
                                        Rect rect = new Rect();
                                        Paint paint = new Paint();
                                        paint.setStyle(Paint.Style.STROKE);
                                        paint.setColor(Color.WHITE);
                                        paint.setStrokeWidth(2);
                                        getLocalVisibleRect(rect);
                                        canvas.drawRect(rect, paint);
                                    }

                                };
                                TableRow.LayoutParams params22 = new TableRow.LayoutParams(120, 47, 1f);
                                opponent.setLayoutParams(params22);
                                opponent.setTextSize(24);

                                opponent.setText(player.getOpponent());
                                opponent.setPadding(6, 4, 6, 4);
                                row.addView(opponent);

                                TextView comp = new android.support.v7.widget.AppCompatTextView(view.getContext()) {
                                    @Override
                                    protected void onDraw(Canvas canvas) {
                                        super.onDraw(canvas);
                                        Rect rect = new Rect();
                                        Paint paint = new Paint();
                                        paint.setStyle(Paint.Style.STROKE);
                                        paint.setColor(Color.WHITE);
                                        paint.setStrokeWidth(2);
                                        getLocalVisibleRect(rect);
                                        canvas.drawRect(rect, paint);
                                    }

                                };
                                TableRow.LayoutParams params2234 = new TableRow.LayoutParams(60, 47, 1f);
                                comp.setLayoutParams(params2234);
                                comp.setTextSize(24);

                                comp.setText(Integer.toString(player.getPassesCompleted()));
                                comp.setPadding(6, 4, 6, 4);
                                row.addView(comp);


                                TextView att = new android.support.v7.widget.AppCompatTextView(view.getContext()) {
                                    @Override
                                    protected void onDraw(Canvas canvas) {
                                        super.onDraw(canvas);
                                        Rect rect = new Rect();
                                        Paint paint = new Paint();
                                        paint.setStyle(Paint.Style.STROKE);
                                        paint.setColor(Color.WHITE);
                                        paint.setStrokeWidth(2);
                                        getLocalVisibleRect(rect);
                                        canvas.drawRect(rect, paint);
                                    }

                                };
                                TableRow.LayoutParams params223 = new TableRow.LayoutParams(50, 47, 1f);
                                att.setLayoutParams(params223);
                                att.setTextSize(24);

                                att.setText(Integer.toString(player.getPassesAttempted()));
                                att.setPadding(6, 4, 6, 4);
                                row.addView(att);


                                TextView comppercentage = new android.support.v7.widget.AppCompatTextView(view.getContext()) {
                                    @Override
                                    protected void onDraw(Canvas canvas) {
                                        super.onDraw(canvas);
                                        Rect rect = new Rect();
                                        Paint paint = new Paint();
                                        paint.setStyle(Paint.Style.STROKE);
                                        paint.setColor(Color.WHITE);
                                        paint.setStrokeWidth(2);
                                        getLocalVisibleRect(rect);
                                        canvas.drawRect(rect, paint);
                                    }

                                };
                                TableRow.LayoutParams params22345 = new TableRow.LayoutParams(70, 47, 1f);
                                comppercentage.setLayoutParams(params22345);
                                comppercentage.setTextSize(24);
                                Float number = 0f;
                                if (player.getPassesAttempted() > 0) {
                                    String print = String.format("%2.02f", (float) (player.getPassesCompleted()) / player.getPassesAttempted());
                                    number = Float.valueOf(print) * 100;
                                }


                                Log.d("hello1234", Float.toString(number));


                                comppercentage.setText(Float.toString(number));
                                comppercentage.setPadding(6, 4, 6, 4);
                                row.addView(comppercentage);

                                TextView yds = new android.support.v7.widget.AppCompatTextView(view.getContext()) {
                                    @Override
                                    protected void onDraw(Canvas canvas) {
                                        super.onDraw(canvas);
                                        Rect rect = new Rect();
                                        Paint paint = new Paint();
                                        paint.setStyle(Paint.Style.STROKE);
                                        paint.setColor(Color.WHITE);
                                        paint.setStrokeWidth(2);
                                        getLocalVisibleRect(rect);
                                        canvas.drawRect(rect, paint);
                                    }

                                };
                                TableRow.LayoutParams params1 = new TableRow.LayoutParams(70, 47, 1f);
                                yds.setLayoutParams(params1);
                                yds.setTextSize(24);

                                yds.setText(Integer.toString(player.getPassingYards()));
                                yds.setPadding(6, 4, 6, 4);
                                row.addView(yds);


                                TextView td = new android.support.v7.widget.AppCompatTextView(view.getContext()) {
                                    @Override
                                    protected void onDraw(Canvas canvas) {
                                        super.onDraw(canvas);
                                        Rect rect = new Rect();
                                        Paint paint = new Paint();
                                        paint.setStyle(Paint.Style.STROKE);
                                        paint.setColor(Color.WHITE);
                                        paint.setStrokeWidth(2);
                                        getLocalVisibleRect(rect);
                                        canvas.drawRect(rect, paint);
                                    }

                                };
                                TableRow.LayoutParams params12 = new TableRow.LayoutParams(45, 47, 1f);
                                td.setLayoutParams(params12);
                                td.setTextSize(24);

                                td.setText(Integer.toString(player.getPassingTD()));
                                td.setPadding(6, 4, 6, 4);
                                row.addView(td);

                                TextView interception = new android.support.v7.widget.AppCompatTextView(view.getContext()) {
                                    @Override
                                    protected void onDraw(Canvas canvas) {
                                        super.onDraw(canvas);
                                        Rect rect = new Rect();
                                        Paint paint = new Paint();
                                        paint.setStyle(Paint.Style.STROKE);
                                        paint.setColor(Color.WHITE);
                                        paint.setStrokeWidth(2);
                                        getLocalVisibleRect(rect);
                                        canvas.drawRect(rect, paint);
                                    }

                                };
                                TableRow.LayoutParams params123 = new TableRow.LayoutParams(25, 47, 1f);
                                interception.setLayoutParams(params123);
                                interception.setTextSize(24);

                                interception.setText(Integer.toString(player.getInterceptions()));
                                interception.setPadding(6, 4, 6, 4);
                                row.addView(interception);

                                TextView rating = new android.support.v7.widget.AppCompatTextView(view.getContext()) {
                                    @Override
                                    protected void onDraw(Canvas canvas) {
                                        super.onDraw(canvas);
                                        Rect rect = new Rect();
                                        Paint paint = new Paint();
                                        paint.setStyle(Paint.Style.STROKE);
                                        paint.setColor(Color.WHITE);
                                        paint.setStrokeWidth(2);
                                        getLocalVisibleRect(rect);
                                        canvas.drawRect(rect, paint);
                                    }

                                };
                                TableRow.LayoutParams param2 = new TableRow.LayoutParams(40, 47, 1f);
                                rating.setLayoutParams(param2);
                                rating.setTextSize(24);

                                rating.setText(Integer.toString(player.getRating()));
                                rating.setPadding(6, 4, 6, 4);
                                row.addView(rating);

                                table.addView(row);


                                //Double rating = algorithms.passerRating(upload.getPassesCompleted(),upload.getPassesAttempted(),upload.getPassingTD(),upload.getInterceptions(),upload.getPassingYards());
                                //rtg.setText(String.valueOf(rating));


                            }
                            }
                        } else {

                            //
                        }
                    } else {
                        //
                    }
                }
            });

















    }




}
