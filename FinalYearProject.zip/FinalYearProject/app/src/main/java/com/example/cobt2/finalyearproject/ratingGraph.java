package com.example.cobt2.finalyearproject;


import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.GridLabelRenderer;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.util.HashMap;


/**
 * A simple {@link Fragment} subclass.
 */
public class ratingGraph extends Fragment {


    // Store instance variables
    private String title;
    private int page;
    private String number;
    GraphView graph;
    int numberofgames;
    LineGraphSeries<DataPoint> series;
    DataPoint[] values;




    // newInstance constructor for creating fragment with arguments
    public static ratingGraph newInstance(int page, String title, String playerselected) {
        ratingGraph fragmentFirst = new ratingGraph();
        Bundle args = new Bundle();
        args.putInt("someInt", page);
        args.putString("someTitle", title);
        args.putString("number",playerselected);
        fragmentFirst.setArguments(args);
        return fragmentFirst;

    }

    // Store instance variables based on arguments passed
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        page = getArguments().getInt("someInt", 0);
        title = getArguments().getString("someTitle");
        number = getArguments().getString("number");

    }

    // Inflate the view for the fragment based on layout XML
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.fragment_rating_graph, container, false);

        FirebaseFirestore db = FirebaseFirestore.getInstance();
        final FrameLayout frame =  view.findViewById(R.id.frame);
        DocumentReference docRef = Players.db.collection("weeks").document("games");
        docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {

                        numberofgames = document.getDouble("numberofgames").intValue();

                        DocumentReference docRef = playerStats.database.collection("weeks").document(number);

                        docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                if (task.isSuccessful()) {
                                    DocumentSnapshot document = task.getResult();
                                    if (document.exists()) {




                                        series = new LineGraphSeries<DataPoint>();



                                        for(int i=1;i<=numberofgames;i++){
                                            if (document.get(Integer.toString(i)) != null){
                                            int x = i;
                                            HashMap<String, Object> myMap = (HashMap<String, Object>) document.get(Integer.toString(i));
                                            Gson gson = new Gson();
                                            JsonElement jsonElement = gson.toJsonTree(myMap);
                                            playerGameWeek player = gson.fromJson(jsonElement, playerGameWeek.class);
                                            double y = player.getRating();

                                            //if(y != 0){

                                            series.appendData(new DataPoint(i,y), false, numberofgames);

                                            //}

                                            }

                                        }
                                        GraphView graph = view.findViewById(R.id.graph);

                                        graph.addSeries(series);
                                        graph.getViewport().setMinX(1);
                                        graph.getGridLabelRenderer().setNumHorizontalLabels(numberofgames);
                                        graph.getGridLabelRenderer().setNumVerticalLabels(5);


                                        graph.getViewport().setMinY(0);
                                        graph.getViewport().setMaxY(5);

                                        graph.getViewport().setYAxisBoundsManual(true);
                                        graph.getViewport().setXAxisBoundsManual(true);
                                        GridLabelRenderer gridLabel = graph.getGridLabelRenderer();
                                        gridLabel.setHorizontalAxisTitle("Week");
                                        gridLabel.setVerticalAxisTitle("Rating");
                                        GridLabelRenderer glr = graph.getGridLabelRenderer();

                                        glr.setPadding(32);
                                        //frame.addView(graph);














                                    } else {
                                        //
                                    }
                                } else {
                                    //
                                }
                            }






                        });




                    } else {

                        //
                    }
                } else {
                    //
                }
            }
        });




        return view;

    }



}
