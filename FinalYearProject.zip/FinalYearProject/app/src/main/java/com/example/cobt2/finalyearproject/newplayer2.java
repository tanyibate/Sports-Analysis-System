package com.example.cobt2.finalyearproject;

import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class newplayer2 extends Fragment {

    Button submit;
    Button selectdate;
    EditText feet;
    EditText inches;
    static int year;
    static int month;
    static int day;
    EditText pounds;
    EditText forty;
    static TextView birthdate;



    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    // The onCreateView method is called when Fragment should create its View object hierarchy,
    // either dynamically or via XML layout inflation.
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup parent, Bundle savedInstanceState) {
        // Defines the xml file for the fragment
        return inflater.inflate(R.layout.fragment_newplayer2, parent, false);

    }

    // This event is triggered soon after onCreateView().
    // Any view setup should occur here.  E.g., view lookups and attaching view listeners.
    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {




        // Setup any handles to view objects here
        // EditText etFoo = (EditText) view.findViewById(R.id.etFoo);
        submit = view.findViewById(R.id.submit);
        selectdate = view.findViewById(R.id.pickdate);
        pounds = view.findViewById(R.id.pounds);
        feet = view.findViewById(R.id.feet);
        inches = view.findViewById(R.id.inches);
        forty = view.findViewById(R.id.fourty);
        birthdate = view.findViewById(R.id.birthdate);
        selectdate.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Code here executes on main thread after user presses button
                DialogFragment newFragment = new DatePickerFragment();
                newFragment.show(getFragmentManager(), "datePicker");
            }
        });
        submit.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Code here executes on main thread after user presses button
                Players.feet = Integer.valueOf(feet.getText().toString());
                Players.inches = Integer.valueOf(inches.getText().toString());
                Players.weight = Integer.valueOf(pounds.getText().toString());
                Players.year = year;
                Players.month = month;
                Players.day = day;
                Players.forty = Float.valueOf(forty.getText().toString());
                Players.addPlayers();
                // Begin the transaction
                // Create new fragment and transaction
                Fragment newFragment = new newplayer();
                FragmentTransaction transaction = getFragmentManager().beginTransaction();

// Replace whatever is in the fragment_container view with this fragment,
// and add the transaction to the back stack if needed
                transaction.replace(R.id.registercontainer, newFragment);
                transaction.addToBackStack(null);

// Commit the transaction
                transaction.commit();


            }
        });


    }

}