package com.example.cobt2.finalyearproject;

import java.util.Calendar;
import java.util.Random;

public class Player {




    // Instance Variables
    String name;
    String position;
    int number;
    int weight;
    int feet;
    int inches;
    float forty;
    int year;
    int month;
    int day;

    //receiving
    int passesCaught;
    int longestReception;
    int receivingTD;

    //passing

    int passesAttempted;
    int passesCompleted;
    int interceptions;
    float passingPercentage;
    int passingYards;
    float yardsPerAttempt;
    int passingTD;
    float yardsPerGame;

    //rushing
    int carries;
    int rushingYards;
    float yardsPerCarry;
    int fumbles;
    int fumblesRecoverd;
    int fumblesLost;
    int rushingTD;

    //defense

    int tackles;
    int assistedTackles;
    int tacklesForLoss;
    int forcedFumbles;
    int dFumblesRecoverd;
    int sacks;
    int dInterceptions;
    float tacklesPerGame;
    int dTD;
    int passesDefended;

    //kicking



    int puntYardsMax;
    int puntTouchBacks;
    int puntSetback;
    int kickoffYardMax;
    int kickoffTouchback;
    int kickoffSetback;
    int fgConverted;
    int fgAttempted;
    int fgLong;

    //returning

    int biggestreturn;
    int returnTD;

    //

    int uniqueID = new Random().nextInt(999999);
    



    public Player(){}

    public Player(String name, String position, int number, int weight, int feet, int inches, float forty, int passesCaught, int longestReception, int receivingTD, int passesAttempted, int passesCompleted, int interceptions, float passingPercentage, int passingYards, float yardsPerAttempt, int passingTD, float yardsPerGame, int carries, int rushingYards, float yardsPerCarry, int fumbles, int fumblesRecoverd, int fumblesLost, int rushingTD, int tackles, int assistedTackles, int tacklesForLoss, int forcedFumbles, int dFumblesRecoverd, int sacks, int dInterceptions, float tacklesPerGame, int dTD, int passesDefended, int puntYardsMax, int puntTouchBacks, int puntSetback, int kickoffYardMax, int kickoffTouchback, int kickoffSetback, int fgConverted, int fgAttempted, int fgLong, int biggestreturn, int returnTD, int uniqueID) {
        this.name = name;
        this.position = position;
        this.number = number;
        this.weight = weight;
        this.feet = feet;
        this.inches = inches;
        this.forty = forty;
        this.passesCaught = passesCaught;
        this.longestReception = longestReception;
        this.receivingTD = receivingTD;
        this.passesAttempted = passesAttempted;
        this.passesCompleted = passesCompleted;
        this.interceptions = interceptions;
        this.passingPercentage = passingPercentage;
        this.passingYards = passingYards;
        this.yardsPerAttempt = yardsPerAttempt;
        this.passingTD = passingTD;
        this.yardsPerGame = yardsPerGame;
        this.carries = carries;
        this.rushingYards = rushingYards;
        this.yardsPerCarry = yardsPerCarry;
        this.fumbles = fumbles;
        this.fumblesRecoverd = fumblesRecoverd;
        this.fumblesLost = fumblesLost;
        this.rushingTD = rushingTD;
        this.tackles = tackles;
        this.assistedTackles = assistedTackles;
        this.tacklesForLoss = tacklesForLoss;
        this.forcedFumbles = forcedFumbles;
        this.dFumblesRecoverd = dFumblesRecoverd;
        this.sacks = sacks;
        this.dInterceptions = dInterceptions;
        this.tacklesPerGame = tacklesPerGame;
        this.dTD = dTD;
        this.passesDefended = passesDefended;
        this.puntYardsMax = puntYardsMax;
        this.puntTouchBacks = puntTouchBacks;
        this.puntSetback = puntSetback;
        this.kickoffYardMax = kickoffYardMax;
        this.kickoffTouchback = kickoffTouchback;
        this.kickoffSetback = kickoffSetback;
        this.fgConverted = fgConverted;
        this.fgAttempted = fgAttempted;
        this.fgLong = fgLong;
        this.biggestreturn = biggestreturn;
        this.returnTD = returnTD;
        this.uniqueID = uniqueID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public int getPassesAttempted() {
        return passesAttempted;
    }

    public void setPassesAttempted(int passesAttempted) {
        this.passesAttempted = passesAttempted;
    }

    public int getPassesCompleted() {
        return passesCompleted;
    }

    public void setPassesCompleted(int passesCompleted) {
        this.passesCompleted = passesCompleted;
    }

    public int getInterceptions() {
        return interceptions;
    }

    public void setInterceptions(int interceptions) {
        this.interceptions = interceptions;
    }

    public float getPassingPercentage() {
        return passingPercentage;
    }

    public void setPassingPercentage(float passingPercentage) {
        this.passingPercentage = passingPercentage;
    }

    public int getPassingYards() {
        return passingYards;
    }

    public void setPassingYards(int passingYards) {
        this.passingYards = passingYards;
    }

    public float getYardsPerAttempt() {
        return yardsPerAttempt;
    }

    public void setYardsPerAttempt(float yardsPerAttempt) {
        this.yardsPerAttempt = yardsPerAttempt;
    }

    public int getPassingTD() {
        return passingTD;
    }

    public void setPassingTD(int passingTD) {
        this.passingTD = passingTD;
    }

    public float getYardsPerGame() {
        return yardsPerGame;
    }

    public void setYardsPerGame(float yardsPerGame) {
        this.yardsPerGame = yardsPerGame;
    }

    public int getCarries() {
        return carries;
    }

    public void setCarries(int carries) {
        this.carries = carries;
    }

    public int getRushingYards() {
        return rushingYards;
    }

    public void setRushingYards(int rushingYards) {
        this.rushingYards = rushingYards;
    }

    public float getYardsPerCarry() {
        return yardsPerCarry;
    }

    public void setYardsPerCarry() {
        this.yardsPerCarry = rushingYards/carries;
    }

    public int getFumbles() {
        return fumbles;
    }

    public void setFumbles(int fumbles) {
        this.fumbles = fumbles;
    }

    public int getFumblesRecoverd() {
        return fumblesRecoverd;
    }

    public void setFumblesRecoverd(int fumblesRecoverd) {
        this.fumblesRecoverd = fumblesRecoverd;
    }

    public int getFumblesLost() {
        return fumblesLost;
    }

    public void setFumblesLost(int fumblesLost) {
        this.fumblesLost = fumblesLost;
    }

    public int getRushingTD() {
        return rushingTD;
    }

    public void setRushingTD(int rushingTD) {
        this.rushingTD = rushingTD;
    }

    public int getTackles() {
        return tackles;
    }

    public void setTackles(int tackles) {
        this.tackles = tackles;
    }

    public int getAssistedTackles() {
        return assistedTackles;
    }

    public void setAssistedTackles(int assistedTackles) {
        this.assistedTackles = assistedTackles;
    }

    public int getTacklesForLoss() {
        return tacklesForLoss;
    }

    public void setTacklesForLoss(int tacklesForLoss) {
        this.tacklesForLoss = tacklesForLoss;
    }

    public int getForcedFumbles() {
        return forcedFumbles;
    }

    public void setForcedFumbles(int forcedFumbles) {
        this.forcedFumbles = forcedFumbles;
    }

    public int getdFumblesRecoverd() {
        return dFumblesRecoverd;
    }

    public void setdFumblesRecoverd(int dFumblesRecoverd) {
        this.dFumblesRecoverd = dFumblesRecoverd;
    }

    public int getSacks() {
        return sacks;
    }

    public void setSacks(int sacks) {
        this.sacks = sacks;
    }

    public int getdInterceptions() {
        return dInterceptions;
    }

    public void setdInterceptions(int dInterceptions) {
        this.dInterceptions = dInterceptions;
    }

    public float getTacklesPerGame() {
        return tacklesPerGame;
    }

    public void setTacklesPerGame(float tacklesPerGame) {
        this.tacklesPerGame = tacklesPerGame;
    }

    public int getdTD() {
        return dTD;
    }

    public void setdTD(int dTD) {
        this.dTD = dTD;
    }

    public int getPuntYardsMax() {
        return puntYardsMax;
    }

    public void setPuntYardsMax(int puntYardsMax) {
        this.puntYardsMax = puntYardsMax;
    }

    public int getPuntTouchBacks() {
        return puntTouchBacks;
    }

    public void setPuntTouchBacks(int puntTouchBacks) {
        this.puntTouchBacks = puntTouchBacks;
    }

    public int getPuntSetback() {
        return puntSetback;
    }

    public void setPuntSetback(int puntSetback) {
        this.puntSetback = puntSetback;
    }

    public int getKickoffYardMax() {
        return kickoffYardMax;
    }

    public void setKickoffYardMax(int kickoffYardMax) {
        this.kickoffYardMax = kickoffYardMax;
    }


    public int getKickoffSetback() {
        return kickoffSetback;
    }

    public void setKickoffSetback(int kickoffSetback) {
        this.kickoffSetback = kickoffSetback;
    }

    public int getPassesDefended() {
        return passesDefended;
    }

    public void setPassesDefended(int passesDefended) {
        this.passesDefended = passesDefended;
    }

    public int getKickoffTouchback() {
        return kickoffTouchback;
    }

    public void setKickoffTouchback(int kickoffTouchback) {
        this.kickoffTouchback = kickoffTouchback;
    }

    public int getPassesCaught() {
        return passesCaught;
    }

    public void setPassesCaught(int passesCaught) {
        this.passesCaught = passesCaught;
    }

    public int getLongestReception() {
        return longestReception;
    }

    public void setLongestReception(int longestReception) {
        this.longestReception = longestReception;
    }


    public int getFgConverted() {
        return fgConverted;
    }

    public void setFgConverted(int fgConverted) {
        this.fgConverted = fgConverted;
    }

    public int getFgAttempted() {
        return fgAttempted;
    }

    public void setFgAttempted(int fgAttempted) {
        this.fgAttempted = fgAttempted;
    }

    public int getFgLong() {
        return fgLong;
    }

    public void setFgLong(int fgLong) {
        this.fgLong = fgLong;
    }

    public int getReceivingTD() {
        return receivingTD;
    }

    public void setReceivingTD(int receivingTD) {
        this.receivingTD = receivingTD;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public int getFeet() {
        return feet;
    }

    public void setFeet(int feet) {
        this.feet = feet;
    }

    public int getInches() {
        return inches;
    }

    public void setInches(int inches) {
        this.inches = inches;
    }

    public float getForty() {
        return forty;
    }

    public void setForty(float forty) {
        this.forty = forty;
    }

    public int getBiggestreturn() {
        return biggestreturn;
    }

    public void setBiggestreturn(int biggestreturn) {
        this.biggestreturn = biggestreturn;
    }

    public int getReturnTD() {
        return returnTD;
    }

    public void setReturnTD(int returnTD) {
        this.returnTD = returnTD;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public int getUniqueID() {
        return uniqueID;
    }

    public void setUniqueID(int uniqueID) {
        this.uniqueID = uniqueID;
    }

    @Override
    public String toString() {
        double fgpercentage = 0;
        if(fgAttempted!=0){
            fgpercentage = (double) (fgConverted/fgAttempted)*100;

        }
        return

                "Passes Caught=" + passesCaught +
                "\n Longest Reception=" + longestReception +
                "\n Receiving Touchdowns=" + receivingTD +
                "\n Passes Attempted=" + passesAttempted +
                "\n Passes Completed=" + passesCompleted +
                "\n Interceptions=" + interceptions +
                "\n Passing Percentage=" + passingPercentage +
                "\n Passing Yards=" + passingYards +
                "\n Yards Per Attempt=" + yardsPerAttempt +
                "\n Passing TD=" + passingTD +
                "\n Yards Per Game=" + yardsPerGame +
                "\n Carries=" + carries +
                "\n Rushing Yards=" + rushingYards +
                "\n Yards Per Carry=" + yardsPerCarry +
                "\n Fumbles=" + fumbles +
                "\n Fumbles Recoverd=" + fumblesRecoverd +
                "\n Fumbles Lost=" + fumblesLost +
                "\n Rushing TD=" + rushingTD +
                "\n Tackles=" + tackles +
                "\n Assisted Tackles=" + assistedTackles +
                "\n Tackles For Loss=" + tacklesForLoss +
                "\n Forced Fumbles=" + forcedFumbles +
                "\n Fumbles Recovered on Defense=" + dFumblesRecoverd +
                "\n Sacks=" + sacks +
                "\n Defensive Interceptions=" + dInterceptions +
                "\n Tackles Per Game=" + tacklesPerGame +
                "\n Defensive Touchdowns=" + dTD +
                "\n Passes Defended=" + passesDefended +
                "\n Biggest Punt=" + puntYardsMax +
                "\n Punt TouchBacks=" + puntTouchBacks +
                //"\n puntSetback=" + puntSetback +
                "\n Biggest Kikckoff Yards =" + kickoffYardMax +
                "\n Kickoff Touchbacks=" + kickoffTouchback +

                "\n Field Goal Completion Percentage=" + fgpercentage +

                "\n Longest Field Goal=" + fgLong +
                "\n Biggest Return=" + biggestreturn +
                "\n Return TD=" + returnTD;
    }
}
