package com.example.cobt2.finalyearproject;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.SystemClock;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Chronometer;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.gson.Gson;
import com.google.gson.JsonElement;

import java.util.ArrayList;
import java.util.HashMap;

public class RecordGame extends AppCompatActivity {
    private Chronometer chronometer;
    private long pauseOffset;
    private boolean running;
    static FirebaseFirestore database;
    static String weekselected;
    static TextView opponent,score;
    public static ArrayList<HashMap<String, String>> list;
    public static final String FIRST_COLUMN="First";
    public static final String SECOND_COLUMN="Second";
    public static final String THIRD_COLUMN="Third";
    public static final String FOURTH_COLUMN="Fourth";

    static ListViewAdapter3 adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record_game);
        Intent intent = getIntent();
        weekselected = intent.getStringExtra("week");
        database = FirebaseFirestore.getInstance();
        populateList();
        adapter =new ListViewAdapter3(this, list);
        DocumentReference doc = database.collection("weeks").document("games");
        doc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {

                        HashMap<String, Object> myMap = (HashMap<String, Object>) document.get(weekselected);
                        Gson gson = new Gson();
                        JsonElement jsonElement = gson.toJsonTree(myMap);
                        opponent gameselected = gson.fromJson(jsonElement, opponent.class);




                        score = findViewById(R.id.score);
                        opponent = findViewById(R.id.opponent);
                        opponent.setText(gameselected.getOpponent());

                        score.setText("Score: LOU "+ gameselected.getTeamscore() + " : " + gameselected.getOpponentscore()+" "+ gameselected.getOpponentabreviation());





                    } else {
                        //
                    }
                } else {
                    //
                }
            }
        });
        Log.d("hello",weekselected);



        chronometer = findViewById(R.id.chronometer);
        chronometer.setFormat("Time: %s");
        chronometer.setBase(SystemClock.elapsedRealtime());

        /*chronometer.setOnChronometerTickListener(new Chronometer.OnChronometerTickListener() {
            @Override
            public void onChronometerTick(Chronometer chronometer) {
                if ((SystemClock.elapsedRealtime() - chronometer.getBase()) >= 10000) {
                    chronometer.setBase(SystemClock.elapsedRealtime());
                    Toast.makeText(RecordGame.this, "Bing!", Toast.LENGTH_SHORT).show();
                }
            }
        });*/

        // Begin the transaction
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        // Replace the contents of the container with the new fragment
        ft.replace(R.id.container, new options());
        // or ft.add(R.id.your_placeholder, new FooFragment());
        // Complete the changes added above
        ft.commit();
    }


    public void startChronometer(View v) {
        if (!running) {
            chronometer.setBase(SystemClock.elapsedRealtime() - pauseOffset);
            chronometer.start();
            running = true;
        }
    }

    public void pauseChronometer(View v) {
        if (running) {
            chronometer.stop();
            pauseOffset = SystemClock.elapsedRealtime() - chronometer.getBase();
            running = false;
        }
    }

    public void resetChronometer(View v) {
        chronometer.setBase(SystemClock.elapsedRealtime());
        pauseOffset = 0;
    }

    public void offence(View view){


// Begin the transaction
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        // Replace the contents of the container with the new fragment
        ft.replace(R.id.container, new Offence());
        // or ft.add(R.id.your_placeholder, new FooFragment());
        // Complete the changes added above
        ft.commit();


    }

    public void pat(View view){


// Begin the transaction
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        // Replace the contents of the container with the new fragment
        ft.replace(R.id.container, new pat());
        // or ft.add(R.id.your_placeholder, new FooFragment());
        // Complete the changes added above
        ft.commit();


    }

    public void kickOff(View view){


// Begin the transaction
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        // Replace the contents of the container with the new fragment
        ft.replace(R.id.container, new Kickoff());
        // or ft.add(R.id.your_placeholder, new FooFragment());
        // Complete the changes added above
        ft.commit();


    }

    public void defense(View view){


// Begin the transaction
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        // Replace the contents of the container with the new fragment
        ft.replace(R.id.container, new Defense());
        // or ft.add(R.id.your_placeholder, new FooFragment());
        // Complete the changes added above
        ft.commit();


    }

    public void punt(View view){


// Begin the transaction
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        // Replace the contents of the container with the new fragment
        ft.replace(R.id.container, new punt());
        // or ft.add(R.id.your_placeholder, new FooFragment());
        // Complete the changes added above
        ft.commit();


    }


    public void point(View view){


// Begin the transaction
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        // Replace the contents of the container with the new fragment
        ft.replace(R.id.container, new twopointconversion());
        // or ft.add(R.id.your_placeholder, new FooFragment());
        // Complete the changes added above
        ft.commit();


    }

    public void ratings(View view){


// Begin the transaction
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        // Replace the contents of the container with the new fragment
        ft.replace(R.id.container, new setratings());
        // or ft.add(R.id.your_placeholder, new FooFragment());
        // Complete the changes added above
        ft.commit();


    }

    public void kickReturn(View view){


// Begin the transaction
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        // Replace the contents of the container with the new fragment
        ft.replace(R.id.container, new kickReturn());
        // or ft.add(R.id.your_placeholder, new FooFragment());
        // Complete the changes added above
        ft.commit();


    }

    public void fieldgoal(View view){


// Begin the transaction
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        // Replace the contents of the container with the new fragment
        ft.replace(R.id.container, new fieldgoal());
        // or ft.add(R.id.your_placeholder, new FooFragment());
        // Complete the changes added above
        ft.commit();


    }

    public void endGame(View view){
        new AlertDialog.Builder(RecordGame.this)
                .setTitle("End Game")
                .setMessage("Are you sure you want to end the game? this action can not be undone")

                // Specifying a listener allows you to take an action before dismissing the dialog.
                // The dialog is automatically dismissed when a dialog button is clicked.
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // Continue with delete operation
                    }
                })

                // A null listener allows the button to dismiss the dialog and take no further action.
                .setNegativeButton(android.R.string.no, null)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }

    public static void populateList() {
        // TODO Auto-generated method stub

        RecordGame.list=new ArrayList<HashMap<String,String>>();



        /*for(int i=0;i<=100;i++) {


            String number = Integer.toString(i);

            DocumentReference docRef = db.collection("players").document(number);
            docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                    if (task.isSuccessful()) {
                        DocumentSnapshot document = task.getResult();
                        if (document.exists()) {
                            Player upload = document.toObject(Player.class);
                            HashMap<String, String> hashmap4 = new HashMap<String, String>();
                            hashmap4.put(FIRST_COLUMN, upload.getName());
                            hashmap4.put(SECOND_COLUMN, upload.getPosition());
                            hashmap4.put(THIRD_COLUMN, Integer.toString(upload.getNumber()));
                            hashmap4.put(FOURTH_COLUMN, "App");
                            list.add(hashmap4);

                        } else {
                            //
                        }
                    } else {
                        //
                    }
                }
            });

        }*/
        RecordGame.database.collection("players")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                Player upload = document.toObject(Player.class);
                                HashMap<String, String> hashmap4 = new HashMap<String, String>();
                                hashmap4.put(FIRST_COLUMN, upload.getName());
                                hashmap4.put(SECOND_COLUMN, upload.getPosition());
                                hashmap4.put(THIRD_COLUMN, Integer.toString(upload.getNumber()));
                                hashmap4.put(FOURTH_COLUMN,  Integer.toString(upload.getUniqueID()));
                                RecordGame.list.add(hashmap4);
                            }
                        } else {

                        }
                    }
                });



    }
}
