package com.example.cobt2.finalyearproject;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;

import java.util.HashMap;
import java.util.Map;

public class Kickoff extends Fragment {

    Button touchback;
    EditText number;
    DocumentReference doc;
    EditText tackledby;
    Button recordtackle;
    Button defense;
    Button restart;
    Button penalty;
    EditText assistedby;
    String week = "1";
    HashMap<String, Integer> tackle = new HashMap<String, Integer>();





    // The onCreateView method is called when Fragment should create its View object hierarchy,
    // either dynamically or via XML layout inflation.
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup parent, Bundle savedInstanceState) {
        // Defines the xml file for the fragment
        return inflater.inflate(R.layout.fragment_kickoff, parent, false);
    }

    // This event is triggered soon after onCreateView().
    // Any view setup should occur here.  E.g., view lookups and attaching view listeners.
    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {

        week = RecordGame.weekselected;

        number = (EditText) view.findViewById(R.id.number);

        touchback = (Button) view.findViewById(R.id.touchback);
        touchback.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                touchbacks();
                // Code here executes on main thread after user presses button
            }
        });
        tackledby = (EditText) view.findViewById(R.id.tackledby);
        recordtackle = (Button) view.findViewById(R.id.recordtackle);
        defense = (Button) view.findViewById(R.id.defense);
        assistedby = view.findViewById(R.id.assistedby);
        restart = (Button) view.findViewById(R.id.restart);
        penalty = view.findViewById(R.id.penalty);
        recordtackle.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                tackle();
                assistedtackle();
                // Code here executes on main thread after user presses button
            }
        });


        // Setup any handles to view objects here
        // EditText etFoo = (EditText) view.findViewById(R.id.etFoo);
    }

    public void touchbacks() {

        doc = RecordGame.database.collection("players").document(number.getText().toString());
        doc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Player kickoff = document.toObject(Player.class);
                        kickoff.setKickoffTouchback(kickoff.getKickoffTouchback()+1);
                        Log.d("hello",touchback.toString());
                        RecordGame.database.collection("players").document(number.getText().toString()).set(kickoff);
                        RecordGame.database.collection("weeks").document(number.getText().toString()).update(RecordGame.weekselected + ".kickoffTouchback", FieldValue.increment(1));



                    } else {
                        //
                    }
                } else {
                    //
                }
            }
        });

    }

    public void tackle() {
        doc = RecordGame.database.collection("players").document(tackledby.getText().toString());
        doc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Player tackle = document.toObject(Player.class);
                        tackle.setTackles(tackle.getTackles()+1);
                        Log.d("hello",touchback.toString());
                        RecordGame.database.collection("players").document(tackledby.getText().toString()).set(tackle);
                        Log.d("hello",RecordGame.weekselected);
                        RecordGame.database.collection("weeks").document(tackledby.getText().toString()).update(RecordGame.weekselected + ".tackles", FieldValue.increment(1));




                    } else {
                        //
                    }
                } else {
                    //
                }
            }
        });

    }

    public void assistedtackle() {
        doc = RecordGame.database.collection("players").document(assistedby.getText().toString());
        doc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Player asssistedtackle = document.toObject(Player.class);
                        asssistedtackle.setAssistedTackles(asssistedtackle.getAssistedTackles()+1);
                        Log.d("hello",touchback.toString());
                        RecordGame.database.collection("players").document(assistedby.getText().toString()).set(asssistedtackle);
                        RecordGame.database.collection("weeks").document(assistedby.getText().toString()).update(RecordGame.weekselected + ".assistedTackles", FieldValue.increment(1));



                    } else {
                        //
                    }
                } else {
                    //
                }
            }
        });

    }

    public void defense(){
        defense.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // TODO Auto-generated method stub
                // Begin the transaction
                // Create new fragment and transaction
                Fragment newFragment = new Defense();
                FragmentTransaction transaction = getFragmentManager().beginTransaction();

// Replace whatever is in the fragment_container view with this fragment,
// and add the transaction to the back stack if needed
                transaction.replace(R.id.container, newFragment);
                transaction.addToBackStack(null);

// Commit the transaction
                transaction.commit();
            }
        });
    }

    public void restart(){
        restart.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // TODO Auto-generated method stub
                // Begin the transaction
                // Create new fragment and transaction
                Fragment newFragment = new Kickoff();
                FragmentTransaction transaction = getFragmentManager().beginTransaction();

// Replace whatever is in the fragment_container view with this fragment,
// and add the transaction to the back stack if needed
                transaction.replace(R.id.container, newFragment);
                transaction.addToBackStack(null);

// Commit the transaction
                transaction.commit();
            }
        });
    }





}
