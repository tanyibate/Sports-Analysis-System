package com.example.cobt2.finalyearproject;

public class games {
    int numberofgames;
    public games(){}

    public games(int numberofgames) {
        this.numberofgames = numberofgames;
    }

    public int getNumberofgames() {
        return numberofgames;
    }

    public void setNumberofgames(int numberofgames) {
        this.numberofgames = numberofgames;
    }
}
